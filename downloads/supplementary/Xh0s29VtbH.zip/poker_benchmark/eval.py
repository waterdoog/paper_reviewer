
def exploitability_upper_bound_stub(policy) -> float:
    """Placeholder: return a mock exploitability; replace with best-response evaluator in production."""
    return 10.0
