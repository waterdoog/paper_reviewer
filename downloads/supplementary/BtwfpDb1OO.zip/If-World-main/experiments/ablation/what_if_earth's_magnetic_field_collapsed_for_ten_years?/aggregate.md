## Ablation Results for What if Earth's magnetic field collapsed for ten years?

| Variant | overall |
|---|---:|
| agents4sci_v2 | 93.00 |
| ablate_two_experts_one_round | 90.00 |
| ablate_no_debate | 88.00 |
| ablate_no_conflict | 79.00 |
| ablate_no_shared_frame | 88.00 |
| ablate_no_refinement | 89.00 |