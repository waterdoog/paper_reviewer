## LLM Evaluation Summary for what_if_earths_magnetic_field_collapsed

| Model | Rigor/Trace (0-25) | Integration/Causality (0-25) | Feasibility/Minimality (0-20) | Uncertainty/Adaptation (0-15) | Decisionability (0-15) | Overall (0-100) |
|---|---:|---:|---:|---:|---:|---:|
| agents4sci_v2 | 22.0 | 23.0 | 17.0 | 13.0 | 14.0 | 89.0 |
| baseline_single | 20.0 | 23.0 | 18.0 | 12.0 | 11.0 | 84.0 |
| baseline_tree | 20.0 | 22.0 | 16.0 | 12.0 | 12.0 | 82.0 |
| baseline_debate | 22.5 | 22.5 | 15.0 | 10.0 | 8.0 | 78.0 |

**Best overall**: `agents4sci_v2` with score 89.00.
