## LLM Evaluation Summary for what_if_all_insects_disappeared

| Model | Rigor/Trace (0-25) | Integration/Causality (0-25) | Feasibility/Minimality (0-20) | Uncertainty/Adaptation (0-15) | Decisionability (0-15) | Overall (0-100) |
|---|---:|---:|---:|---:|---:|---:|
| agents4sci_v2 | 18.0 | 22.0 | 18.0 | 13.0 | 14.0 | 85.0 |
| baseline_single | 23.0 | 22.0 | 17.0 | 12.0 | 10.0 | 84.0 |
| baseline_tree | 24.0 | 21.0 | 18.0 | 14.0 | 13.0 | 90.0 |
| baseline_debate | 22.0 | 23.0 | 17.0 | 13.0 | 12.0 | 87.0 |

**Best overall**: `baseline_tree` with score 90.00.
