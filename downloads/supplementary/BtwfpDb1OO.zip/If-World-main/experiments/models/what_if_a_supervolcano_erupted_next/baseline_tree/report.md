# Cross-Domain Analysis: Supervolcano Eruption Next Year  
*Proposition: A supervolcano erupts next year. Analysis includes two variants exploring distinct assumptions and causal branches.*  


## **1. Overview**  
A "supervolcano" refers to a volcanic system capable of VEI 8 eruptions (≥1,000 km³ magma output), ejecting massive tephra (ash/pumice) and sulfur dioxide (SO₂) into the atmosphere. Examples include Yellowstone (USA), Lake Taupo (New Zealand), and Long Valley (USA). This analysis explores two plausible variants of such an eruption, differing in magnitude, timing, and human preparedness, to assess cross-domain impacts, uncertainties, and adaptation.  


## **2. Variant 1: Moderate Supervolcano Eruption**  
*Key Assumptions*:  
- **Location**: A VEI 7 eruption (500–800 km³ magma) at Mount Aso (Japan) or Mount Mazama (Oregon, USA).  
- **Magnitude**: 50 Tg SO₂ (10x Mount Pinatubo, 1991), stratospheric aerosol layer lasting 1–2 years.  
- **Preparedness**: 6–12 months of pre-eruption unrest detected; partial evacuation of high-risk zones (e.g., 50% of 1M people near Aso).  


### **2.1 Domain Analysis**  
| **Domain**       | **Causal Chain**                                                                 | **Key Impacts**                                                                 | **Feasibility**                                                                 |  
|-------------------|----------------------------------------------------------------------------------|---------------------------------------------------------------------------------|---------------------------------------------------------------------------------|  
| **Geology**       | Magma chamber collapse → lateral blast (10–50 km radius) + 100–500 km² ash fall. | Local infrastructure destruction; 1–5 m ash accumulation in nearby regions.      | Eruption timing (days to weeks after unrest detected) is predictable.           |  
| **Climate**       | SO₂ aerosols reflect sunlight → 0.5–1.5°C global cooling (1–2 years).            | Reduced growing season (temperatures drop 2–3°C in mid-latitudes); altered rainfall. | SO₂ injection into stratosphere (10–20 km altitude) is critical for long-term cooling. |  
| **Human Health**  | Ash inhalation → respiratory failure; acid rain → skin/water contamination.      | 10–50k direct deaths (local); 100k+ indirect deaths (respiratory, cardiovascular). | Pre-evacuation reduces exposure; medical stockpiles (e.g., inhalers) mitigate effects. |  
| **Agriculture**   | Ash burial + reduced sunlight → crop failure (10–30% global yield loss).         | 50–100M food-insecure people; 30–50% price spike for rice/wheat.                | Limited pre-positioned food reserves (e.g., 10% of global grain stocks) can buffer short-term shortages. |  
| **Infrastructure**| Ash loading (1–5 cm/mm²) → building collapse; jet engine damage → air traffic halt. | 50%+ disruption to air travel; power grid failures (ash clogs transformers).     | Partial evacuation of airports; temporary ash-removal teams (e.g., 10k workers/day) can restore 50% capacity in 2 months. |  
| **Economy**       | Supply chain disruptions + food shortages → 1–3% global GDP contraction.         | Stock market volatility (5–10% drop); insurance claims ($100–300B).             | Regional trade blocs (e.g., EU, ASEAN) can coordinate food aid; central banks may inject $500B+ in stimulus. |  


## **3. Variant 2: Severe Supervolcano Eruption**  
*Key Assumptions*:  
- **Location**: A VEI 8 eruption (≥1,000 km³ magma) at Yellowstone (USA) or Lake Taupo (New Zealand).  
- **Magnitude**: 150 Tg SO₂ (3x Pinatubo), stratospheric aerosol layer lasting 2–3 years.  
- **Preparedness**: No pre-eruption unrest detected; minimal evacuation (e.g., 10% of 3M people near Yellowstone).  


### **3.1 Domain Analysis**  
| **Domain**       | **Causal Chain**                                                                 | **Key Impacts**                                                                 | **Feasibility**                                                                 |  
|-------------------|----------------------------------------------------------------------------------|---------------------------------------------------------------------------------|---------------------------------------------------------------------------------|  
| **Geology**       | Global tephra fall (1000+ km²) + caldera collapse → 100–1000 m tephra in mid-latitudes. | 90%+ infrastructure damage in affected regions; 100M+ displaced.                | No pre-warning makes large-scale evacuation impossible.                          |  
| **Climate**       | SO₂ aerosols reflect sunlight → 1.5–3°C global cooling (2–3 years).              | "Volcanic winter": 5–10°C drops in polar regions; crop failures globally.         | Stratospheric aerosol layer may cause polar vortex disruption (e.g., extreme winters in N. Hemisphere). |  
| **Human Health**  | Ash inhalation + acid rain → 1M+ direct deaths; 1M+ deaths from starvation/extreme cold. | 25% mortality in unprotected populations; mental health crises (PTSD, social collapse). | No pre-evacuation; medical systems overwhelmed (e.g., 10x normal demand for emergency care). |  
| **Agriculture**   | Global crop failure (50–70% yield loss); 1B+ food-insecure people.               | 30–50% global food price spike; 50–100M risk of starvation.                      | No pre-positioned reserves can buffer 70% loss; global supply chains collapse.   |  
| **Infrastructure**| 100% air traffic halt; power grids collapse (ash clogs 90% of transformers).     | 6+ months of power outages; 90%+ communication failure.                         | No rapid repair capacity (1M workers needed, but 50% unavailable due to ash).    |  
| **Economy**       | Global supply chain collapse + societal breakdown → 5–10% global GDP contraction. | 25% unemployment; 50% of global businesses insolvent.                           | No global coordination (e.g., UN-led aid) due to communication failures.        |  


## **4. Uncertainties & Adaptation**  
### **Uncertainties**  
- **Eruption Parameters**: SO₂ output (50–150 Tg) and stratospheric residence time (1–3 years) depend on magma composition and eruption column height.  
- **Climate Sensitivity**: Volcanic cooling may be amplified by Arctic sea ice loss (positive feedback) or offset by increased CO₂ (negative feedback).  
- **Human Response**: Preparedness (e.g., evacuation, aid) varies by country; only 10–30% of high-risk populations may be protected even with warning.  


### **Adaptation Strategies**  
- **Short-Term (0–6 months)**:  
  - Stockpile emergency supplies (food, medical kits) in high-risk zones.  
  - Deploy "ash vacuums" (e.g., industrial fans) to clear power lines.  
  - Implement "solar radiation management" (SRM) via sulfate aerosols (unproven, but could reduce cooling by 30–50% if deployed within 2 weeks of eruption).  
- **Long-Term (1–5 years)**:  
  - Develop "climate-resilient" crops (drought/frost-tolerant varieties).  
  - Build underground infrastructure (e.g., bunkers for food storage, medical facilities).  
  - Establish global "volcanic early warning networks" (e.g., USGS, GNS Science) with AI-driven prediction models.  


## **5. Scenarios & Timeline**  
| **Phase**       | **Timeline** | **Key Events**                                                                 |  
|-----------------|--------------|--------------------------------------------------------------------------------|  
| **Immediate**   | 0–1 month    | Eruption; local ash fall; air traffic disruption.                             |  
| **Short-Term**  | 1–6 months   | Ash settles; power/communication failures; regional food shortages.           |  
| **Medium-Term** | 6–2 years    | Global cooling; crop failures; economic contraction; societal strain.          |  
| **Long-Term**   | 2+ years     | Recovery (infrastructure rebuilding, climate adaptation); new "volcanic climate" patterns. |  


## **6. Traceability & Consistency**  
- **Claims** (e.g., "1.5–3°C cooling") are based on scaling Mount Pinatubo’s 0.5°C cooling (20 Tg SO₂) to 150 Tg SO₂ (7.5x) and accounting for stratospheric residence time (1–3 years).  
- **Feasibility constraints** (e.g., SRM’s unproven side effects) are explicitly noted; no collapse narratives (e.g., "civilization ends")—instead, "partial societal disruption" with 10–50% mortality in worst-case scenarios.  


**Conclusion**: A supervolcano eruption next year would cause global disruption, with impacts ranging from regional ash fall (Variant 1) to global collapse (Variant 2). Preparedness and adaptation are critical, but uncertainties in eruption magnitude and human response make precise projections impossible.