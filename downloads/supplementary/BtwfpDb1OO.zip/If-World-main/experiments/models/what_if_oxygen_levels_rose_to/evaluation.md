## LLM Evaluation Summary for what_if_oxygen_levels_rose_to

| Model | Rigor/Trace (0-25) | Integration/Causality (0-25) | Feasibility/Minimality (0-20) | Uncertainty/Adaptation (0-15) | Decisionability (0-15) | Overall (0-100) |
|---|---:|---:|---:|---:|---:|---:|
| agents4sci_v2 | 18.0 | 20.0 | 16.0 | 13.0 | 12.0 | 79.0 |
| baseline_single | 20.0 | 22.0 | 18.0 | 12.0 | 10.0 | 82.0 |
| baseline_tree | 22.0 | 23.0 | 18.0 | 14.0 | 12.0 | 89.0 |
| baseline_debate | 22.0 | 20.0 | 16.0 | 12.0 | 11.0 | 81.0 |

**Best overall**: `baseline_tree` with score 89.00.
