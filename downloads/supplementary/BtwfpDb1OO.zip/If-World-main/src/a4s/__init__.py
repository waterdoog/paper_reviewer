"""a4s: Agents-for-Science multi-agent hypothetical scenario reasoning system.

This package provides:
- LLM client wrapper for Volcengine Ark (Doubao) via OpenAI SDK
- Agent implementations: Problem Refiner, Domain Experts, Conflict Resolver, Report Generator
- Orchestrator to run multi-round parallel reasoning and consolidation

Guiding principles:
- Prefer natural language for rich reasoning; only use JSON when structure is essential
- Keep interfaces explicit and typed for clarity and maintainability
"""

__all__ = [
    "orchestrator",
]

