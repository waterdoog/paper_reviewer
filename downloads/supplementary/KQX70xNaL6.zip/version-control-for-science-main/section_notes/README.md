# Section Notes

This folder contains working notes for paper sections.