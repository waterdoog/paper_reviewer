# PeerQA Decontextualization Audit - All Methods Results

**Dataset**: Real PeerQA JSONL files
**Samples Processed**: 579
**Source**: 579 real Q&As, 90 papers

## Best Performing Configurations

| Retriever | Best Config | Recall@10 | MRR |
|-----------|-------------|-----------|-----|
| bm25_oracle | paragraph/minimal | 1.000 | 0.679 |

## Detailed Results by Configuration

### sentence/minimal

**Retrieval Performance:**
- bm25_oracle: Recall@10=0.774, MRR=0.474

**Downstream Tasks:**
- bm25_oracle: Accuracy=0.580, F1=0.658

### sentence/title_only

**Retrieval Performance:**
- bm25_oracle: Recall@10=0.771, MRR=0.473

**Downstream Tasks:**
- bm25_oracle: Accuracy=0.580, F1=0.661

### sentence/heading_only

**Retrieval Performance:**
- bm25_oracle: Recall@10=0.775, MRR=0.473

**Downstream Tasks:**
- bm25_oracle: Accuracy=0.567, F1=0.650

### sentence/title_heading

**Retrieval Performance:**
- bm25_oracle: Recall@10=0.769, MRR=0.472

**Downstream Tasks:**
- bm25_oracle: Accuracy=0.600, F1=0.674

### sentence/aggressive_title

**Retrieval Performance:**
- bm25_oracle: Recall@10=0.770, MRR=0.474

**Downstream Tasks:**
- bm25_oracle: Accuracy=0.581, F1=0.662

### paragraph/minimal

**Retrieval Performance:**
- bm25_oracle: Recall@10=1.000, MRR=0.679

**Downstream Tasks:**
- bm25_oracle: Accuracy=0.609, F1=0.683

### paragraph/title_only

**Retrieval Performance:**
- bm25_oracle: Recall@10=0.994, MRR=0.553

**Downstream Tasks:**
- bm25_oracle: Accuracy=0.611, F1=0.684

### paragraph/heading_only

**Retrieval Performance:**
- bm25_oracle: Recall@10=0.994, MRR=0.567

**Downstream Tasks:**
- bm25_oracle: Accuracy=0.592, F1=0.671

### paragraph/title_heading

**Retrieval Performance:**
- bm25_oracle: Recall@10=0.994, MRR=0.545

**Downstream Tasks:**
- bm25_oracle: Accuracy=0.625, F1=0.696

### paragraph/aggressive_title

**Retrieval Performance:**
- bm25_oracle: Recall@10=1.000, MRR=0.680

**Downstream Tasks:**
- bm25_oracle: Accuracy=0.647, F1=0.713

