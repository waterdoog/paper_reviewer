# Paper Drafts

This folder contains research paper drafts.