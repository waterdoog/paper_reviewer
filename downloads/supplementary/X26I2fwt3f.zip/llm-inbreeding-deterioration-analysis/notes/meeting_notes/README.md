# Meeting Notes

This folder contains meeting notes, discussions, and collaborative notes.

## Format Suggestions

- Use date-based naming: `2024-01-15-weekly-meeting.md`
- Include attendees and key decisions
- Link to relevant experiments or papers when discussed
```
