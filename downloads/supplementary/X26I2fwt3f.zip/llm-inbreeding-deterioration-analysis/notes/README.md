# Notes

This folder is for researchers to dump their notes, thoughts, and informal documentation.

## Subfolders

- `meeting_notes/` - Meeting notes, discussions, and collaborative notes
- `code/` - Code snippets, quick scripts, and development notes

Feel free to organize your notes however works best for your research workflow!