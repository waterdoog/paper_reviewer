gs -dPDFA=2 -dBATCH -dNOPAUSE -dNOOUTERSAVE -sPROCESSCOLORS=DEVICECMYK -sDEVICE=pdfwrite -sPDFACompatibilityPolicy=1 -sOutputFile=main_pdfa.pdf main.pdf
