# Submission Package

Includes paper (LaTeX), figures, bib, results, code stubs, data metadata, prompts, and admin files.

## Build the paper
```bash
cd paper
bash build.sh
```
## Reproduce (lightweight)
```bash
cd code
python3 execute_experiments.py
```
