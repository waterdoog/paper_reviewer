ASSIGNMENT_PROMPT='Agents4Science workflow with idea→math→code→experiments→paper→review'
