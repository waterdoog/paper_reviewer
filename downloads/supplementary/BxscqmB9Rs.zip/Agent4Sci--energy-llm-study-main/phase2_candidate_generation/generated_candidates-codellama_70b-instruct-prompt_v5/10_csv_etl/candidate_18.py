import io
import csv

# Example usage:

csv_data = """Name,City
John,New York
Jane,Tokyo"""

print(solve(csv_data))