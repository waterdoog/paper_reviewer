# Examples

This section provides examples and tutorials for using the HMM-GLM Sports framework.

## Basic Examples

- [Basic Usage](basic_usage.md): Getting started with HMM-GLM
- [Data Loading](data_loading.md): Loading and preprocessing data
- [Model Training](model_training.md): Training HMM-GLM models
- [Model Evaluation](model_evaluation.md): Evaluating model performance

## Advanced Examples

- [Multimodal Integration](multimodal_integration.md): Integrating multiple data modalities
- [Context-Aware Transitions](context_aware_transitions.md): Using context-aware transition matrices
- [Class Imbalance Handling](class_imbalance.md): Handling class imbalance with various weighting strategies
- [NHL-Specific Adjustments](nhl_adjustments.md): Applying NHL-specific adjustments for goalie influence

## Sport-Specific Examples

- [MLB Analysis](mlb_analysis.md): Analyzing baseball performance
- [NBA Analysis](nba_analysis.md): Analyzing basketball performance
- [NHL Analysis](nhl_analysis.md): Analyzing hockey performance
