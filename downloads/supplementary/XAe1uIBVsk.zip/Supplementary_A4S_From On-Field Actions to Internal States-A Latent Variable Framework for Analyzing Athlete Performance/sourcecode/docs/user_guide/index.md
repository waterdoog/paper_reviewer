# User Guide

This guide will help you get started with the HMM-GLM Sports framework.

## Contents

- [Installation](installation.md)
- [Basic Usage](basic_usage.md)
- [Data Collection](data_collection.md)
- [Data Preprocessing](data_preprocessing.md)
- [Model Configuration](model_configuration.md)
- [Training and Evaluation](evaluation.md)
- [Advanced Features](advanced_features.md)

## Introduction

The HMM-GLM Sports framework provides a powerful approach for modeling latent performance states in sports using Hidden Markov Models (HMMs) and Generalized Linear Models (GLMs). This hybrid approach allows for capturing both temporal dependencies in athlete performance and the relationship between latent states and observable outcomes.

Key features of the framework include:

- **Latent State Modeling**: Identify and analyze hidden performance states that drive observed outcomes.
- **Context-Aware Transitions**: Model how game context affects state transitions.
- **Class Imbalance Handling**: Advanced weighting strategies to address class imbalance in sports data.
- **Multimodal Data Integration**: Combine spatiotemporal, biomechanical, and physiological data.
- **Sport-Specific Adjustments**: Special handling for sport-specific factors (e.g., goalie influence in hockey).
- **Model Variants**: Multiple model variants for different analytical needs.

The following sections will guide you through the process of installing the framework, collecting and preprocessing data, configuring and training models, and evaluating results.
