# HMM-GLM Sports Documentation

Welcome to the HMM-GLM Sports documentation. This framework provides tools for modeling latent performance states in sports using Hidden Markov Models (HMMs) and Generalized Linear Models (GLMs).

## Contents

- [User Guide](user_guide/index.md): Getting started with the framework
- [API Reference](api/index.md): Detailed API documentation
- [Examples](examples/index.md): Example usage and tutorials

## Quick Links

- [Installation](user_guide/installation.md)
- [Basic Usage](user_guide/basic_usage.md)
- [Model Evaluation](user_guide/evaluation.md)
- [Advanced Features](user_guide/advanced_features.md)
