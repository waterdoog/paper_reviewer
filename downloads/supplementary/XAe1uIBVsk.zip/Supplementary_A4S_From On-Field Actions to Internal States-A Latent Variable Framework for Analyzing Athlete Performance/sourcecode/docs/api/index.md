# API Reference

This section provides detailed documentation for the HMM-GLM Sports API.

## Core Modules

- [core.hmm_glm](core/hmm_glm.md): Core HMM-GLM implementation
- [core.context_transitions](core/context_transitions.md): Context-aware transition matrices
- [core.weighting](core/weighting.md): Class imbalance handling strategies

## Data Modules

- [data.loader](data/loader.md): Data loading utilities
- [data.preprocessing](data/preprocessing.md): Data preprocessing functions
- [data.crawlers](data/crawlers.md): Data collection from sports APIs
- [data.converters](data/converters.md): Data conversion utilities

## Evaluation Modules

- [evaluation.metrics](evaluation/metrics.md): Performance metrics
- [evaluation.visualization](evaluation/visualization.md): Visualization tools
- [evaluation.comparison](evaluation/comparison.md): Model comparison utilities

## Feature Modules

- [features.engineering](features/engineering.md): Feature engineering utilities
- [features.selection](features/selection.md): Feature selection methods

## Model Modules

- [models.variants](models/variants.md): Model variants and extensions
