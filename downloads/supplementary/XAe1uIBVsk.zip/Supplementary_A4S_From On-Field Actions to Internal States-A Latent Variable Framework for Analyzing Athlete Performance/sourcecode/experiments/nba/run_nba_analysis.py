#!/usr/bin/env python
"""
NBA Analysis Experiment

This script performs HMM-GLM analysis on NBA data.
"""

import os
import sys
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.data import load_nba_data, extract_shots_data
from src.core.hmm_glm import CategoricalHMMComponent, LogisticGLMComponent, HMMGLMModel
from src.evaluation import evaluate_model, plot_confusion_matrix, compare_with_baseline
from src.evaluation import plot_state_transitions, plot_feature_importance


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='NBA Analysis Experiment')
    parser.add_argument('--data-path', type=str, default='data',
                        help='Path to data directory')
    parser.add_argument('--seasons', type=str, nargs='+', default=['2022', '2023'],
                        help='Seasons to analyze')
    parser.add_argument('--n-states', type=int, default=3,
                        help='Number of hidden states')
    parser.add_argument('--min-shots', type=int, default=100,
                        help='Minimum number of shots for a player to be included')
    parser.add_argument('--output-dir', type=str, default='results/nba',
                        help='Output directory for results')
    
    return parser.parse_args()


def create_player_datasets(df, min_shots=100):
    """Create datasets for each player with sufficient shots."""
    # Group by player
    player_groups = df.groupby('player1_id')
    
    # Filter players with sufficient shots
    player_counts = player_groups.size()
    qualified_players = player_counts[player_counts >= min_shots].index
    
    print(f"Found {len(qualified_players)} players with at least {min_shots} shots")
    
    # Create datasets
    player_datasets = {}
    for player_id in qualified_players:
        player_df = df[df['player1_id'] == player_id].copy()
        
        # Create sequences based on game_id
        player_df['sequence_id'] = player_df.groupby('game_id').ngroup()
        
        # Extract features and target
        X = player_df[[
            'period', 'game_time_norm', 'score_differential_norm',
            'shot_distance', 'shot_angle', 'is_three_pointer',
            'shot_clock_pressure', 'game_pressure'
        ]].values
        
        y = player_df['is_made'].values
        sequences = player_df['sequence_id'].values
        
        player_datasets[player_id] = {
            'X': X,
            'y': y,
            'sequences': sequences,
            'player_name': player_df['player1_name'].iloc[0],
            'n_shots': len(player_df),
            'fg_pct': player_df['is_made'].mean()
        }
    
    return player_datasets


def run_analysis(player_datasets, n_states=3, output_dir='results/nba'):
    """Run HMM-GLM analysis for each player."""
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Initialize results
    results = []
    
    # Analyze each player
    for player_id, data in player_datasets.items():
        print(f"Analyzing player {data['player_name']} (ID: {player_id})")
        
        try:
            # Create and fit model
            hmm_comp = CategoricalHMMComponent(n_states=n_states, n_categories=2)
            glm_comp = LogisticGLMComponent()
            model = HMMGLMModel(hmm_component=hmm_comp, glm_component=glm_comp)
            
            model.fit(data['X'], data['y'], sequences=data['sequences'])
            
            # Evaluate model
            metrics = evaluate_model(model, data['X'], data['y'], sequences=data['sequences'])
            
            # Compare with baseline
            baseline_comparison = compare_with_baseline(
                model, data['X'], data['y'], sequences=data['sequences'],
                baseline_type='logistic'
            )
            
            # Get state sequences
            states = model.predict_states(data['X'], sequences=data['sequences'])
            state_counts = np.bincount(states, minlength=n_states)
            state_proportions = state_counts / len(states)
            
            # Calculate FG% by state
            fg_pcts = []
            for state in range(n_states):
                state_mask = (states == state)
                if np.sum(state_mask) > 0:
                    fg_pct = np.mean(data['y'][state_mask])
                    fg_pcts.append(fg_pct)
                else:
                    fg_pcts.append(np.nan)
            
            # Add to results
            results.append({
                'player_id': player_id,
                'player_name': data['player_name'],
                'n_shots': data['n_shots'],
                'fg_pct': data['fg_pct'],
                'accuracy': metrics['accuracy'],
                'auc': metrics['auc'],
                'brier_score': metrics['brier_score'],
                'delta_loglikelihood': metrics['delta_loglikelihood'],
                'state_diversity': metrics['state_diversity'],
                'baseline_accuracy': baseline_comparison.loc[baseline_comparison['model'] == 'Logistic Regression', 'accuracy'].values[0],
                'baseline_auc': baseline_comparison.loc[baseline_comparison['model'] == 'Logistic Regression', 'auc'].values[0],
                'state_proportions': state_proportions.tolist(),
                'state_fg_pcts': fg_pcts
            })
            
            # Create visualizations
            fig, axes = plt.subplots(2, 2, figsize=(12, 10))
            
            # Plot confusion matrix
            y_pred = model.predict(data['X'], sequences=data['sequences'])
            plot_confusion_matrix(data['y'], y_pred, ax=axes[0, 0])
            
            # Plot state transitions
            plot_state_transitions(model.hmm_component.model.transmat_, ax=axes[0, 1])
            
            # Plot FG% by state
            axes[1, 0].bar(range(n_states), fg_pcts)
            axes[1, 0].set_xlabel('State')
            axes[1, 0].set_ylabel('FG%')
            axes[1, 0].set_title('Field Goal Percentage by State')
            
            # Plot state proportions
            axes[1, 1].bar(range(n_states), state_proportions)
            axes[1, 1].set_xlabel('State')
            axes[1, 1].set_ylabel('Proportion')
            axes[1, 1].set_title('State Proportions')
            
            # Save figure
            fig.suptitle(f"Player: {data['player_name']} (ID: {player_id})")
            plt.tight_layout(rect=[0, 0, 1, 0.95])
            plt.savefig(os.path.join(output_dir, f"player_{player_id}.png"))
            plt.close()
            
            # Feature importance
            feature_names = [
                'Period', 'Game Time', 'Score Diff',
                'Shot Distance', 'Shot Angle', '3PT',
                'Shot Clock Pressure', 'Game Pressure'
            ]
            
            fig = plot_feature_importance(model, feature_names=feature_names)
            fig.suptitle(f"Feature Importance: {data['player_name']}")
            plt.tight_layout(rect=[0, 0, 1, 0.95])
            plt.savefig(os.path.join(output_dir, f"player_{player_id}_features.png"))
            plt.close()
            
        except Exception as e:
            print(f"Error analyzing player {player_id}: {e}")
    
    # Save results
    results_df = pd.DataFrame(results)
    results_df.to_csv(os.path.join(output_dir, 'results.csv'), index=False)
    
    return results_df


def main():
    """Main function."""
    args = parse_args()
    
    # Load data
    print(f"Loading NBA data from {args.data_path}")
    nba_data = load_nba_data(args.data_path, seasons=args.seasons)
    
    # Extract shot data
    shots_df = extract_shots_data(nba_data, sport='nba')
    
    # Create player datasets
    player_datasets = create_player_datasets(shots_df, min_shots=args.min_shots)
    
    # Run analysis
    results_df = run_analysis(player_datasets, n_states=args.n_states, output_dir=args.output_dir)
    
    # Print summary
    print("\nAnalysis Summary:")
    print(f"Number of players analyzed: {len(results_df)}")
    print(f"Average accuracy: {results_df['accuracy'].mean():.3f}")
    print(f"Average AUC: {results_df['auc'].mean():.3f}")
    print(f"Average improvement over baseline: {(results_df['accuracy'] - results_df['baseline_accuracy']).mean():.3f}")
    
    # Find players with highest improvement
    results_df['improvement'] = results_df['accuracy'] - results_df['baseline_accuracy']
    top_players = results_df.sort_values('improvement', ascending=False).head(5)
    
    print("\nTop 5 players with highest improvement:")
    for _, row in top_players.iterrows():
        print(f"{row['player_name']}: {row['improvement']:.3f} improvement, {row['accuracy']:.3f} accuracy")


if __name__ == '__main__':
    main()
