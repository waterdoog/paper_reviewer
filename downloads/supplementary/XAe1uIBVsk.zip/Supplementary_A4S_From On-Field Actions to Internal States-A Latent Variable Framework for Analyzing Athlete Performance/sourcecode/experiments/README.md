# Experiments

This directory contains experiment scripts for running HMM-GLM analysis on different sports datasets.

## MLB Experiments

The `mlb` directory contains experiments for analyzing baseball data.

```bash
# Run MLB analysis
python experiments/mlb/run_mlb_analysis.py --data-path data --seasons 2022 2023 --n-states 3 --min-atbats 50 --output-dir results/mlb
```

## NBA Experiments

The `nba` directory contains experiments for analyzing basketball data.

```bash
# Run NBA analysis
python experiments/nba/run_nba_analysis.py --data-path data --seasons 2022 2023 --n-states 3 --min-shots 100 --output-dir results/nba
```

## NHL Experiments

The `nhl` directory contains experiments for analyzing hockey data, including goalie impact adjustments.

```bash
# Run NHL analysis without goalie adjustments
python experiments/nhl/run_nhl_analysis.py --data-path data --seasons 2022 2023 --n-states 3 --min-shots 50 --output-dir results/nhl

# Run NHL analysis with goalie adjustments
python experiments/nhl/run_nhl_analysis.py --data-path data --seasons 2022 2023 --n-states 3 --min-shots 50 --output-dir results/nhl_adjusted --adjust-for-goalie
```

## Common Parameters

All experiment scripts support the following common parameters:

- `--data-path`: Path to data directory (default: `data`)
- `--seasons`: Seasons to analyze (default: `2022 2023`)
- `--n-states`: Number of hidden states (default: `3`)
- `--min-shots` / `--min-atbats`: Minimum number of shots/at-bats for a player to be included
- `--output-dir`: Output directory for results

## Results

Each experiment script generates the following outputs:

- `results.csv`: CSV file with results for each player
- Player-specific visualizations:
  - `player_{id}.png`: Confusion matrix, state transitions, outcome rates by state, and state proportions
  - `player_{id}_features.png`: Feature importance by state
