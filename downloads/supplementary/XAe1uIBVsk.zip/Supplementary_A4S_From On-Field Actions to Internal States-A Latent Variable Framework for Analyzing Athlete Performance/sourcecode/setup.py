from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as f:
    requirements = f.read().splitlines()
    # Remove comments and empty lines
    requirements = [r for r in requirements if not r.startswith("#") and r.strip()]

setup(
    name="hmm_glm_sports",
    version="0.1.0",
    author="HMM-GLM Sports Team",
    author_email="author@example.com",
    description="HMM-GLM framework for analyzing athlete performance in sports",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/hmm-glm-sports",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Information Analysis",
    ],
    python_requires=">=3.8",
    install_requires=[
        # Core requirements only - users can install optional dependencies as needed
        "numpy>=1.20.0",
        "pandas>=1.3.0",
        "scipy>=1.7.0",
        "scikit-learn>=1.0.0",
        "matplotlib>=3.4.0",
        "seaborn>=0.11.0",
        "hmmlearn>=0.2.7",
        "statsmodels>=0.13.0",
        "tqdm>=4.62.0",
        "joblib>=1.1.0",
    ],
    extras_require={
        "crawlers": [
            "requests>=2.27.0",
            "beautifulsoup4>=4.10.0",
            "lxml>=4.7.0",
            "selenium>=4.1.0",
            "webdriver-manager>=3.5.0",
        ],
        "ml": ["xgboost>=1.5.0", "tensorflow>=2.8.0", "torch>=1.10.0"],
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=3.0.0",
            "black>=22.1.0",
            "flake8>=4.0.0",
            "isort>=5.10.0",
        ],
        "docs": ["sphinx>=4.4.0", "sphinx-rtd-theme>=1.0.0"],
        "all": [
            "requests>=2.27.0",
            "beautifulsoup4>=4.10.0",
            "lxml>=4.7.0",
            "selenium>=4.1.0",
            "webdriver-manager>=3.5.0",
            "xgboost>=1.5.0",
            "tensorflow>=2.8.0",
            "torch>=1.10.0",
            "plotly>=5.5.0",
            "jupyter>=1.0.0",
            "ipywidgets>=7.6.0",
            "pytest>=7.0.0",
            "pytest-cov>=3.0.0",
            "sphinx>=4.4.0",
            "sphinx-rtd-theme>=1.0.0",
            "black>=22.1.0",
            "flake8>=4.0.0",
            "isort>=5.10.0",
        ],
    },
)