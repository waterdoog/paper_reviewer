"""
Context-aware transition matrices for HMM.
"""

from .context_transitions import (
    compute_context_dependent_transitions,
    update_context_dependent_transitions,
    initialize_context_parameters
)

__all__ = [
    'compute_context_dependent_transitions',
    'update_context_dependent_transitions',
    'initialize_context_parameters'
]


