"""
HMM-GLM framework for modeling latent performance states.
"""

from .hmm_component import (
    HMMComponent,
    CategoricalHMMComponent,
    GaussianHMMComponent
)

from .glm_component import (
    GLMComponent,
    LogisticGLMComponent,
    PoissonGLMComponent
)

from .hmm_glm_model import HMMGLMModel

from .evaluation import (
    evaluate_hmm_glm_model,
    calculate_delta_log_likelihood,
    compare_with_baseline
)

from .visualization import (
    plot_state_transition_matrix,
    plot_emission_probabilities,
    plot_state_sequence,
    plot_delta_log_likelihood_distribution,
    plot_state_goal_probabilities
)

__all__ = [
    'HMMComponent',
    'CategoricalHMMComponent',
    'GaussianHMMComponent',
    'GLMComponent',
    'LogisticGLMComponent',
    'PoissonGLMComponent',
    'HMMGLMModel',
    'evaluate_hmm_glm_model',
    'calculate_delta_log_likelihood',
    'compare_with_baseline',
    'plot_state_transition_matrix',
    'plot_emission_probabilities',
    'plot_state_sequence',
    'plot_delta_log_likelihood_distribution',
    'plot_state_goal_probabilities'
]


