"""
Converters for transforming crawled data into formats compatible with the HMM-GLM framework.

This package provides utilities to convert raw crawled data from various sports leagues
into standardized formats that can be directly used by the HMM-GLM models.
"""

from .mlb_converter import convert_mlb_data, MLBDataConverter
from .nba_converter import convert_nba_data, NBADataConverter
from .nhl_converter import convert_nhl_data, NHLDataConverter

__all__ = [
    'convert_mlb_data', 'MLBDataConverter',
    'convert_nba_data', 'NBADataConverter',
    'convert_nhl_data', 'NHLDataConverter'
]

