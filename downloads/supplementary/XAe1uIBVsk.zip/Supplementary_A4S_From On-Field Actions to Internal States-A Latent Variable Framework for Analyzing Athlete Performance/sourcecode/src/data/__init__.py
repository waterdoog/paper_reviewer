"""
Data loading, preprocessing, and collection utilities for sports data.
"""

from .loader import (
    load_nhl_data,
    load_mlb_data,
    load_nba_data,
    extract_shots_data,
    load_and_extract_shots,
    load_crawled_data,
    load_and_convert_crawled_data
)

# Import crawlers if available
try:
    from .crawlers import MLBCrawler, NBACrawler, NHLCrawler
except ImportError:
    pass  # Crawlers are optional

from .preprocessing import (
    preprocess_nhl_shots,
    preprocess_mlb_atbats,
    preprocess_nba_shots,
    calculate_rolling_stats,
    split_train_test,
    create_player_datasets
)

from .sequence import (
    extract_sequences,
    extract_sequence_features,
    create_sequence_datasets,
    create_player_sequence_datasets,
    sequence_length,
    time_since_last_event,
    count_event_type,
    has_event_type,
    last_event_type
)

__all__ = [
    # Data loading
    'load_nhl_data',
    'load_mlb_data',
    'load_nba_data',
    'extract_shots_data',
    'load_and_extract_shots',
    
    # Data preprocessing
    'preprocess_nhl_shots',
    'preprocess_mlb_atbats',
    'preprocess_nba_shots',
    'calculate_rolling_stats',
    'split_train_test',
    'create_player_datasets',
    
    # Sequence utilities
    'extract_sequences',
    'extract_sequence_features',
    'create_sequence_datasets',
    'create_player_sequence_datasets',
    'sequence_length',
    'time_since_last_event',
    'count_event_type',
    'has_event_type',
    'last_event_type'
]

# Add crawler classes if available
try:
    __all__.extend(['MLBCrawler', 'NBACrawler', 'NHLCrawler'])
except NameError:
    pass  # Crawlers are not imported

# Add converter functions if available
try:
    from .converters import convert_mlb_data, convert_nba_data, convert_nhl_data
    __all__.extend(['convert_mlb_data', 'convert_nba_data', 'convert_nhl_data'])
except ImportError:
    pass  # Converters are not imported

# Add crawler data loading functions
__all__.extend(['load_crawled_data', 'load_and_convert_crawled_data'])

