"""
Feature engineering and multimodal data integration utilities.
"""

from .engineering import (
    add_time_features,
    add_score_differential_features,
    add_spatial_features,
    add_rolling_stats,
    add_opponent_features,
    add_game_context_features
)

from .multimodal import (
    integrate_spatiotemporal_features,
    integrate_biomechanical_features,
    integrate_physiological_features,
    integrate_multimodal_features,
    extract_multimodal_features
)

from .nhl_specific import (
    model_goalie_save_probability,
    adjust_shooter_performance,
    calculate_goalie_quality_index,
    integrate_goalie_adjustments
)

__all__ = [
    'add_time_features',
    'add_score_differential_features',
    'add_spatial_features',
    'add_rolling_stats',
    'add_opponent_features',
    'add_game_context_features',
    'integrate_spatiotemporal_features',
    'integrate_biomechanical_features',
    'integrate_physiological_features',
    'integrate_multimodal_features',
    'extract_multimodal_features',
    'model_goalie_save_probability',
    'adjust_shooter_performance',
    'calculate_goalie_quality_index',
    'integrate_goalie_adjustments'
]


