"""
Evaluation module for HMM-GLM models.

This module provides utilities for evaluating HMM-GLM models, including metrics,
visualization tools, and model comparison functionality.
"""

from .metrics import (
    calculate_accuracy,
    calculate_auc,
    calculate_brier_score,
    calculate_log_loss,
    calculate_delta_loglikelihood,
    calculate_state_diversity,
    evaluate_model
)

from .visualization import (
    plot_confusion_matrix,
    plot_roc_curve,
    plot_precision_recall_curve,
    plot_calibration_curve,
    plot_state_transitions,
    plot_state_distributions,
    plot_feature_importance
)

from .comparison import (
    compare_models,
    compare_with_baseline,
    statistical_significance_test,
    cross_validation_comparison
)

__all__ = [
    # Metrics
    'calculate_accuracy',
    'calculate_auc',
    'calculate_brier_score',
    'calculate_log_loss',
    'calculate_delta_loglikelihood',
    'calculate_state_diversity',
    'evaluate_model',
    
    # Visualization
    'plot_confusion_matrix',
    'plot_roc_curve',
    'plot_precision_recall_curve',
    'plot_calibration_curve',
    'plot_state_transitions',
    'plot_state_distributions',
    'plot_feature_importance',
    
    # Comparison
    'compare_models',
    'compare_with_baseline',
    'statistical_significance_test',
    'cross_validation_comparison'
]
