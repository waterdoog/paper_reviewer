1. Do the main claims made in the abstract and introduction accurately reflect the paper's contributions and scope?
2. Does the paper discuss the limitations of the work performed by the authors?
3. For each theoretical result, does the paper provide the full set of assumptions and a complete (and correct) proof?
4. Does the paper fully disclose all the information needed to reproduce the main experimental results of the paper to the extent that it affects the main claims and/or conclusions of the paper (regardless of whether the code and data are provided or not)?
5. Does the paper provide open access to the data and code, with sufficient instructions to faithfully reproduce the main experimental results, as described in supplemental material?
6. Does the paper specify all the training and test details (e.g., data splits, hyperparameters, how they were chosen, type of optimizer, etc.) necessary to understand the results?
7. Does the paper report error bars suitably and correctly defined or other appropriate information about the statistical significance of the experiments?
8. For each experiment, does the paper provide sufficient information on the computer resources (type of compute workers, memory, time of execution) needed to reproduce the experiments?
9. Does the research conducted in the paper conform, in every respect, with the Agents4Science Code of Ethics (see conference website)?
10. Does the paper discuss both potential positive societal impacts and negative societal impacts of the work performed?
