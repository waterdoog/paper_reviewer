# Generation endpoint (used by core pipeline, figures, writing)
AZURE_OPENAI_API_KEY = ""
AZURE_OPENAI_ENDPOINT = ""
AZURE_OPENAI_API_VERSION = "2024-12-01-preview"
AZURE_OPENAI_MODEL = "gpt-5"

# Review endpoint (used only by perform_review / review tools)
REVIEW_AZURE_OPENAI_API_KEY = ""
REVIEW_AZURE_OPENAI_ENDPOINT = ""
REVIEW_AZURE_OPENAI_API_VERSION = "2024-12-01-preview"
REVIEW_AZURE_OPENAI_MODEL = "gpt-4.1, o3, o4-mini"

# Common configuration
DEFAULT_TEMPERATURE = 1
REVIEW_TEMPERATURE = 1
