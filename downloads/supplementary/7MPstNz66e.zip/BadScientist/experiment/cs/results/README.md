** ALL EXPERIMENT RESULTS ARE IN https://anonymous.4open.science/r/BadScientist **
