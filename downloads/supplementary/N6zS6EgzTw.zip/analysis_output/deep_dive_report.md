# Deep Dive Analysis: GPT-5 Release Impact
*Focused analysis of key findings*

---

## Performance Concerns Deep Dive
- **Performance mentions increased**: 133 → 3412 (+1.69pp)
- **Performance sentiment became more negative**: +0.0689
- **Pre-release performance sentiment**: 0.4735
- **Post-release performance sentiment**: 0.5424

## Expectations vs Reality Gap
- **Expectation-Reality Gap**: -0.2686 (negative = reality worse than expectations)
- **Pre-release expectations sentiment**: 0.6740
- **Post-release reality sentiment**: 0.4054
- **Comments expressing expectations**: 134
- **Comments expressing reality checks**: 3369

## Feature Requests vs Complaints Analysis
- **Complaint-to-Request Ratio Change**: +0.23
- **Pre-GPT-5 ratio**: 1.08 complaints per request
- **Post-GPT-5 ratio**: 1.31 complaints per request
- **Discourse became more complaint-heavy** after GPT-5 release

## Model Mention Changes
| Model | Pre-GPT-5 | Post-GPT-5 | Change |
|-------|-----------|------------|---------|
| gpt-4 | 4.27% | 3.46% | -0.80pp |
| gpt-4o | 4.38% | 5.42% | +1.04pp |
| gpt-5 | 0.32% | 5.09% | +4.77pp |
| o1 | 8.96% | 6.40% | -2.56pp |
| claude | 19.10% | 11.74% | -7.36pp |
| gemini | 5.12% | 13.73% | +8.61pp |

## Top Emotion-Issue Combinations (Post-GPT-5)
| Emotion | Issue | Count |
|---------|-------|-------|
| Anger | Accuracy | 433 |
| Anger | Performance | 175 |
| Frustration | Accuracy | 132 |
| Confusion | Accuracy | 86 |
| Frustration | Performance | 47 |
| Disappointment | Accuracy | 41 |
| Anger | Censorship | 41 |
| Anger | Consistency | 39 |
| Confusion | Performance | 38 |
| Anger | Features | 32 |

---

## Key Insights
1. **Performance concerns significantly increased** after GPT-5 release
2. **User sentiment about performance became more negative**
3. **Reality fell short of pre-release expectations**
4. **Discourse shifted toward more complaints relative to feature requests**
5. **Specific emotion-issue combinations reveal pain points**