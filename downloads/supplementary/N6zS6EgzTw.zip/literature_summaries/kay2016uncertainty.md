# Kay et al. (2016) — Uncertainty Visualization in Everyday Predictive Systems

Citation Key: kay2016uncertainty

## 1. Core Contribution
Design space + empirical evaluation of user-centered uncertainty visualizations for bus arrival predictions.

## 2. Study Design & Methods
- Field/lab hybrid; compares textual vs probabilistic vs range visual encodings.

## 3. Key Findings
- Users can interpret carefully designed approximate (“ish”) ranges; aids planning.
- Overly technical statistical representations reduce usability.

## 4. Limitations
- Transportation domain specificity.
- Limited longitudinal habituation measurement.

## 5. Relevance to Mutual Wanting
- Motivates structured uncertainty surfacing (confidence tokens) for model version changes.

## 6. Metrics / Design Impact
- Supports Structured Uncertainty Ratio; informs encoding taxonomy for prompt output formatting.

## 7. Integration Plan
Related Work (uncertainty disclosure) + design rationale for confidence scaffolds.

## 8. Open Questions
- What minimal textual uncertainty token set keeps comprehension high without clutter?
