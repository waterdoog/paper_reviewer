# Horton & Wohl (1956) — Para-Social Interaction

Citation Key: horton1956mass

## 1. Core Contribution
Introduces parasocial interaction concept: one-sided, media-mediated intimacy perceptions toward performers.

## 2. Method / Nature
- Conceptual + qualitative observational analysis of broadcast media audiences.

## 3. Key Insights
- Predictable interaction rituals cultivate perceived reciprocity.
- Disruptions to format can break perceived relationship continuity.

## 4. Limitations
- Pre-digital context; lacks interactive agency.
- Does not address algorithmic adaptation.

## 5. Relevance to Mutual Wanting
- Personality discontinuity parallels format disruption—model update shifts style, breaking ritualized expectations.

## 6. Metrics / Design Impact
- Justifies coding for ritual language (“my AI always used to…”) as parasocial continuity marker.

## 7. Integration Plan
Related Work (parasocial foundations) + framing of emotional backlash to version shifts.

## 8. Open Questions
- How to design opt-in ritual preservation during model retraining?
