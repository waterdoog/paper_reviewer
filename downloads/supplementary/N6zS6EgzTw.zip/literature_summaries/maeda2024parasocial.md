# Maeda & Quan-Haase (2024) — Parasocial Human-AI Interactions

Citation Key: maeda2024parasocial

## 1. Core Contribution
Examines emergence of parasocial dynamics in affective AI design; agency cues amplify anthropomorphic bonding.

## 2. Study Design & Methods
- Empirical study (details to verify—assumed survey + interaction logs) focusing on affective agent features.

## 3. Key Findings (Provisional)
- Higher anthropomorphic framing correlates with increased emotional attribution.
- Users negotiate boundaries when affective cues misalign with perceived competence.

## 4. Limitations
- Need to confirm sample size & methodological rigor.
- Possible self-selection toward emotionally engaged users.

## 5. Relevance to Mutual Wanting
- Underpins Intimacy Boundary interventions and prompts to avoid over-ascription during version shifts.

## 6. Metrics / Design Impact
- Suggests adding Dependence Risk Proxy: lexical markers of emotional reliance in discourse.

## 7. Integration Plan
Related Work (parasocial modern context) + Ethics (dependency mitigation).

## 8. Verification Needed
- Retrieve exact methodology, stats, and limitations for accuracy.
