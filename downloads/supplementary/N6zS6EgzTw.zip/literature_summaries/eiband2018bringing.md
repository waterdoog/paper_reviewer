# Eiband et al. (2018) — Bringing Transparency Design into Practice

Citation Key: eiband2018bringing

## 1. Core Contribution
Offers practitioner-oriented framework translating abstract transparency ideals into concrete UI patterns.

## 2. Study Design & Methods
- Case study analyses of deployed systems + design workshops.
- Derivation of pattern catalog (timing, modality, granularity).

## 3. Key Findings
- Transparency must be situated (task + user mental model maturity).
- Layered, on-demand disclosure outperforms static info dumps.

## 4. Limitations
- Lacks quantitative evaluation of pattern efficacy.
- Potential selection bias in chosen systems.

## 5. Relevance to Mutual Wanting
- Directly informs Router Transparency intervention (progressive disclosure for routing rationale, model selection cues).

## 6. Metrics / Design Impact
- Supports measuring Confidence Disclosure Rate (frequency of optional transparency layers invoked in logs / proxies in discourse).

## 7. Integration Plan
Related Work → transparency; Methodology → design heuristics for interface mock audits.

## 8. Open Questions
- How to operationalize *adaptive* transparency for model version transitions without cognitive overload?
