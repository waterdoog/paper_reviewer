# (arXiv 2507.10695) — Privacy Attitudes Toward LLM Chatbots for Mental Health

Citation Key: mentalhealth2025privacy

## 1. Core Contribution (Provisional)
Characterizes user security and privacy concerns using LLMs for mental health contexts; informs boundary design.

## 2. Method (To Verify)
- Likely mixed-method survey + qualitative coding; accepted to USENIX Security 2025.

## 3. Key Expected Insights
- Concerns over data retention, secondary use, model training reuse of sensitive content.
- Trust conditional on clear disclosure + consent affordances.

## 4. Limitations
- Self-reported attitudes subject to hypothetical bias.

## 5. Relevance to Mutual Wanting
- Informs Intimacy Boundaries intervention: explicit delineation of non-retention and scope of use.

## 6. Metrics / Design Impact
- Supports dependence risk mitigation via privacy reassurance cues balancing Warmth-Cost tradeoff.

## 7. Integration Plan
Ethics + Related Work (privacy in relational AI) + Design implications.

## 8. Verification Needed
- Extract precise methodology, sample size, quantified concern prevalence.
