# Yin et al. (2019) — Understanding the Effect of Accuracy on Trust

Citation Key: yin2019understanding

## 1. Core Contribution
Demonstrates nuanced relationship between presented accuracy levels and user trust, showing miscalibration risks when accuracy info is partial or decontextualized.

## 2. Study Design & Methods
- Controlled experiment varying accuracy disclosures.
- Measures: user trust ratings, reliance behaviors.

## 3. Key Findings
- Overly optimistic accuracy reporting leads to overreliance.
- Absent contextual uncertainty fosters assumption of stability.

## 4. Limitations
- Task-specific (classification-like decisions); ecological validity limited.
- Short-term exposure; no longitudinal adaptation.

## 5. Relevance to Mutual Wanting
- Underlines need for dynamic disclosure when model capabilities shift (version transitions).
- Supports our metric: Trust Calibration Gap.

## 6. Metrics / Design Impact
- Suggests capturing user-perceived vs empirically measured helpfulness in Reddit complaints about regressions.

## 7. Integration Plan
Related Work (trust calibration) + Metrics rationale.

## 8. Open Questions
- How does perceived regression vs improvement asymmetry affect recalibration latency?
