# (PNAS 2025) — The Benefits and Dangers of Anthropomorphic Conversational Agents

Citation Key: pnas2025anthro

## 1. Core Contribution (Provisional)
Analyzes dual-edge effects of anthropomorphic design in conversational agents on user trust, engagement, and potential overreliance / miscalibrated expectations.

## 2. Method (To Verify)
- Likely multi-condition user experiments varying anthropomorphic cues (name, avatar, self-referential language) measuring trust, compliance, perceived competence.

## 3. Key Expected Insights
- Moderate anthropomorphism may increase engagement but heighten perceived intentionality of errors.
- Over-anthropomorphizing increases felt betrayal on regression.

## 4. Limitations (Anticipated)
- Lab context vs longitudinal real-world usage.
- Cultural variance in anthropomorphism reception not fully covered.

## 5. Relevance to Mutual Wanting
- Directly informs personality discontinuity mitigation strategies (stability cues vs persona overreach).

## 6. Metrics / Design Impact
- Motivates Warmth-Cost Tension Index balancing personable cues vs reliability signals.

## 7. Integration Plan
Related Work (anthropomorphic design trade-offs) + Discussion (risk management in version updates).

## 8. Verification Needed
- Update with authors, DOI, sample sizes, statistical effect directions.
