# Kizilcec (2016) — Effects of Transparency on Trust

Citation Key: kizilcec2016much

## 1. Core Contribution
Empirically examines how varying transparency levels influence user trust and perceived competence.

## 2. Study Design & Methods
- Experimental manipulation: low vs medium vs high transparency explanations.
- Measures: trust ratings, perceived understanding, reliance.

## 3. Key Findings
- Moderate transparency maximizes calibrated trust; excessive detail can erode confidence.
- User prior expertise moderates optimal level.

## 4. Limitations
- Artificial task environment; limited ecological transfer.
- Short-term exposure; no adaptation curve analysis.

## 5. Relevance to Mutual Wanting
- Suggests dynamic tuning of disclosure intensity across model life stages.

## 6. Metrics / Design Impact
- Supports Warmth-Cost Tension Index: balance between personable reassurance vs cognitive load of details.

## 7. Integration Plan
Related Work (transparency-trust curve) + Metrics justification.

## 8. Open Questions
- Can discourse signals predict when users seek deeper transparency layers?
