# Lai & Tan (2019) — Human-AI Collaboration in Decision Making

Citation Key: lai2019human

## 1. Core Contribution
Shows explanations can increase decision confidence and appropriate reliance in human-AI collaborative settings.

## 2. Study Design & Methods
- Comparative user study: baseline vs explanation conditions.
- Measures: decision accuracy, confidence alignment, reliance behaviors.

## 3. Key Findings
- Explanations improve calibration when faithful and appropriately scoped.
- Over-detailed explanations can distract; relevance filtering matters.

## 4. Limitations
- Domain-limited (text classification style tasks).
- Explanation style not exhaustively compared.

## 5. Relevance to Mutual Wanting
- Informs design of Prompt Provenance surfaces (traceable reasoning steps vs opaque outputs).

## 6. Metrics / Design Impact
- Motivates introducing a Structured Uncertainty Ratio: proportion of outputs accompanied by structured rationale or uncertainty tokens.

## 7. Integration Plan
Related Work (human-AI collaboration and explanations) + Framework operationalization.

## 8. Open Questions
- Does explanation provenance reduce perceived personality discontinuity in version changes?
