# (arXiv 2505.07142) — Anthropomorphism for Environmental Sustainability

Citation Key: envsustain2025anthro

## 1. Core Contribution (Provisional)
Explores whether anthropomorphic conversational framing increases pro-environmental engagement or sustained behavior change.

## 2. Method (To Verify)
- Presumed experimental chatbot interventions with sustainability prompts.

## 3. Key Expected Insights
- Anthropomorphism may boost short-term intent but uncertain long-term habit adherence.

## 4. Limitations
- Domain-specific motivational bias; generalization to productivity or creative use unclear.

## 5. Relevance to Mutual Wanting
- Illustrates domain-specific modulation of anthropomorphism benefits; warns against blanket persona strategies.

## 6. Metrics / Design Impact
- Suggest conditioning Warmth-Cost balance analyses by domain context in Reddit threads (creative, coding, research, emotional support).

## 7. Integration Plan
Related Work (anthropomorphism domain transfer) + Limitations.

## 8. Verification Needed
- Confirm authors, experimental design, effect sizes.
