# Epley, Waytz & Cacioppo (2007) — Three-Factor Theory of Anthropomorphism

Citation Key: epley2007seeing

## 1. Core Contribution
Proposes that anthropomorphism arises from (a) elicited agent knowledge, (b) effectance motivation, (c) sociality motivation.

## 2. Type / Method
- Theoretical synthesis + illustrative empirical references (no single large new experiment).

## 3. Key Insights
- Predictability gaps heighten effectance motivation → more attribution of human-like traits.
- Loneliness/social deprivation increases sociality motivation → stronger anthropomorphic projection.

## 4. Limitations
- Framework-era pre-modern LLM context; needs reinterpretation for adaptive language agents.

## 5. Relevance to Mutual Wanting
- Helps interpret personality discontinuity complaints as effectance failures (loss of controllability mental model).

## 6. Metrics / Design Impact
- Suggest coding Reddit posts for effectance vs sociality triggers; correlate with anthropomorphism language frequency.

## 7. Integration Plan
Related Work (anthropomorphism foundations) + Discussion of over-ascription risks in version transitions.

## 8. Open Questions
- Can proactive capability change narratives reduce effectance-motivated anthropomorphism spikes?
