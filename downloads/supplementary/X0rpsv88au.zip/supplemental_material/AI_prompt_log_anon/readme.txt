The PDFs have been anonymized as some texts copied into the prompts contained sensitive information (e.g., user name as part of a path).
