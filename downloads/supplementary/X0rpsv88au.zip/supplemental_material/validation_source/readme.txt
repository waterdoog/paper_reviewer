Used with this requirements.txt
Python Version 3.12.9

.env has been anonymized to remove sensitive URL information.

PS: This is a Python environment used for different experiments, so the requirements are by no means minimal for this source.

