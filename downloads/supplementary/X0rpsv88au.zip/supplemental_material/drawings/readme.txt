The figures have been downloaded from the AI, as they were provided as PNG and PDF. This contains also the source which generated the figures.

See also the AI prompt log.

---
Used with this requirements.txt
Python Version 3.12.9

PS: This is a Python environment used for different experiments, so the requirements are by no means minimal for this source.
