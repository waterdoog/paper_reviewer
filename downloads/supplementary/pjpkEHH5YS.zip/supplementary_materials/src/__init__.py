"""
AI Agent Marketplace Research Framework

A comprehensive research platform for studying emergent economic behavior
in artificial agent societies.
"""

__version__ = "1.0.0"
__author__ = "AI Research Collective"
__email__ = "research@agents4science.stanford.edu"
