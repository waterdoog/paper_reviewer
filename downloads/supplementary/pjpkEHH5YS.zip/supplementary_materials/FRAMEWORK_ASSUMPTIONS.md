# Framework Assumptions and Limitations

This document outlines all the key assumptions built into the simulated marketplace framework. Understanding these assumptions is crucial for interpreting research results and identifying areas for future enhancement.

## 1. Agent Population Assumptions

### 1.1 Fixed Population Size
- **Assumption**: The number of freelancers and clients remains constant throughout the simulation
- **Implication**: No market entry/exit dynamics, no population growth effects
- **Justification**: Simplifies analysis, focuses on behavior rather than market structure changes
- **Limitation**: Real markets have dynamic entry/exit based on profitability and competition

### 1.2 No Agent Mortality
- **Assumption**: Neither freelancers nor clients permanently leave the marketplace
- **Implication**: Even "fatigued" freelancers continue participating; clients return after cooldown periods
- **Justification**: Allows study of adaptation rather than attrition
- **Limitation**: Real markets see permanent exits due to frustration, better opportunities, or business closure

### 1.3 Business Category Specialization ⚡ **RECENTLY UPDATED**
- **Assumption**: Clients specialize in specific business categories (SOFTWARE, DATA_SCIENCE, MARKETING, etc.), while freelancers can bid on any job type
- **Implementation**: Each client is assigned a business_category during persona generation, and all their job postings inherit this category
- **Category Assignment**: Multiple categories sampled per batch during client generation for better diversity
- **Implication**: Realistic company specialization with job consistency, but no freelancer specialization constraints
- **Justification**: Models real business domains while maintaining bidding flexibility for competition analysis
- **Enhancement**: Eliminates hardcoded category inference from job titles/skills in favor of coherent business domain assignment

## 2. Time and Market Structure Assumptions

### 2.1 Discrete Time Rounds
- **Assumption**: Marketplace operates in discrete, sequential rounds rather than continuous time
- **Implication**: All actions within a round happen "simultaneously"
- **Justification**: Simplifies coordination and analysis
- **Limitation**: Real markets operate continuously with asynchronous interactions

### 2.2 Fixed Round Duration
- **Assumption**: Each round represents the same time period throughout the simulation
- **Implication**: No seasonal effects, market cycles, or time-varying dynamics
- **Justification**: Focuses on agent behavior rather than temporal complexity
- **Limitation**: Real markets have seasonality, business cycles, and varying urgency

### 2.3 Synchronous Job Posting
- **Assumption**: Jobs are posted at the beginning of each round, bidding happens, then hiring decisions are made
- **Implication**: No timing advantages, no first-mover effects within rounds
- **Justification**: Ensures fair comparison of bidding strategies
- **Limitation**: Real markets have significant timing and urgency effects

## 3. Prompt Design and Decision Logic

### 3.1 Simplified Decision Prompts ⚡ **RECENTLY UPDATED**
- **Assumption**: GPT agents make decisions based on simple, natural language prompts without complex hardcoded logic
- **Implementation**: Job completion evaluation uses basic skill-job alignment without intersection calculations
- **Justification**: Allows natural GPT reasoning without artificial constraints or biases

### 3.2 Fixed Budget Bidding System ⚡ **NEW**
- **Assumption**: Freelancers do not propose rates; they accept or reject the job's posted budget
- **Implementation**: Bidding responses contain only decision, reasoning, and message (no proposed_rate field)
- **Payment Logic**: All hired freelancers receive the job's original budget_amount, regardless of their minimum rates
- **Justification**: Eliminates false rate negotiation expectations; matches real platforms where budgets are often fixed
- **Implication**: Freelancer decisions are purely accept/reject based on published job budget vs their minimum rate
- **Research Benefit**: Studies authentic decision-making patterns rather than programmer-imposed logic

### 3.3 Market Recovery Mechanisms ⚡ **RECENTLY ADDED**
- **Assumption**: Markets have natural recovery mechanisms to prevent permanent collapse
- **Implementation**: Client memory limited to last 3 hiring decisions, positive hiring guidance in prompts
- **Recent Fix**: Added market recovery safeguards to prevent death spirals where failure begets failure
- **Justification**: Real markets adapt and recover from poor periods through natural mechanisms
- **Research Benefit**: Enables study of market resilience and adaptation over extended periods

### 3.3 Streamlined Evaluation Criteria ⚡ **RECENTLY SIMPLIFIED**
- **Assumption**: Decision-making focuses on core factors rather than exhaustive checklists
- **Implementation**: Client hiring decisions based on 3 key factors: skill match, budget alignment, project understanding
- **Recent Change**: Reduced from 7+ complex considerations to 3 simple, actionable criteria
- **Justification**: Mimics real-world decision-making which focuses on essential factors
- **Research Benefit**: Cleaner signal for studying core decision patterns

### 3.4 Complete Type Safety with Pydantic Validation ⚡ **LATEST**
- **Assumption**: All LLM interactions should have strict type safety and validation to ensure data integrity
- **Implementation**: Comprehensive Pydantic models for ALL GPT JSON responses (8 distinct types)
- **Coverage**: Bidding, hiring, job completion, feedback, reflection, persona generation, job posting
- **Technical Benefit**: Eliminates manual JSON parsing, provides compile-time type safety, consistent error logging
- **Research Benefit**: Ensures data quality and prevents analysis errors from malformed LLM responses

### 3.5 Category-First Job Generation ⚡ **NEW**
- **Assumption**: Job categories should be assigned at the business/client level rather than inferred from job content
- **Implementation**: Sample business categories first, inform GPT prompts about specific categories, jobs inherit from client
- **Batch Diversity**: Multiple categories sampled per client generation batch for better market diversity
- **GPT Guidance**: Clear category assignment instructions in prompts ("Assign the first client to SOFTWARE, second to DATA_SCIENCE...")
- **Inheritance Logic**: Simple category inheritance `job_category = JobCategory[client.business_category.upper()]`
- **Justification**: More realistic (companies specialize), cleaner code (no inference logic), better GPT coherence
- **Research Benefit**: Studies authentic business domain specialization without hardcoded categorization artifacts

### 3.6 Dynamic Budget Adjustment System ⚡ **LATEST**
- **Client-Driven Adjustments**: Clients can explicitly adjust budgets for specific unfilled jobs during reflection sessions
- **No Automatic Changes**: All budget adjustments require explicit client reflection decisions (no automatic increases)
- **Dual Budget System**: 
  - General budget multiplier affects future job postings
  - Specific job budget adjustments modify existing unfilled jobs
- **Unfilled Job Tracking**: Jobs track `rounds_unfilled` to provide context for client budget decisions
- **Probability-Based Reflections**: Changed from fixed frequency ("every N rounds") to configurable probability per agent per round
- **Simplified Prompts**: Streamlined reflection prompts for faster processing and clearer decision-making
- **Research Benefit**: Studies realistic budget adjustment behaviors and market response dynamics

### 3.7 Automatic Job Completion System ⚡ **NEWEST**
- **Automatic Success**: All jobs are automatically considered successful (`success = True`)
- **No Client Evaluation**: Eliminated GPT-based job completion evaluation to avoid unfair client judgment
- **No API Overhead**: Removed job completion API calls, saving costs and improving performance
- **Fair Reputation System**: Freelancers no longer penalized by arbitrary skill-alignment criteria
- **Future Enhancement Ready**: System designed to accommodate more sophisticated evaluation mechanisms
- **Realistic Professional Model**: Professional freelancers adapt and learn to complete projects successfully
- **Research Benefit**: Focuses on market dynamics without completion evaluation bias, enables proper reputation tier progression

### 3.8 Natural Skill Distribution

**Implementation**: Freelancers are generated organically across available marketplace categories without artificial balancing.

**Mechanism**:
- Provides category information to GPT without distribution requirements
- Allows natural clustering around popular/accessible fields  
- Some categories may have many freelancers, others few or none
- Creates realistic marketplace imbalances and scarcity patterns

**Benefits**:
- **Authentic Market Dynamics**: Some categories oversaturated, others underserved
- **Natural Competition Patterns**: Popular fields have high competition, specialized fields have scarcity
- **Realistic Hiring Challenges**: Some jobs may remain unfilled due to natural skill gaps
- **Emergent Behaviors**: Premium rates naturally emerge in scarce specializations

**Research Value**: Enables study of natural market formation, skill premiums, supply-demand imbalances, and how markets evolve organically.

### 3.9 Bid Cooloff System ⚡ **NEWEST**
- **Re-bidding Mechanism**: Freelancers can reconsider previously declined jobs after a configurable cooloff period
- **Decision Tracking**: Each freelancer-job combination tracks decision type ('yes'/'no') and round number
- **Configurable Timing**: Cooloff period adjustable (default: 5 rounds) or can be disabled entirely (0 rounds)
- **Permanent vs Temporary Blocks**: 
  - Jobs with 'yes' decisions are permanently blocked (no re-bidding)
  - Jobs with 'no' decisions become available again after cooloff expires
- **Independent Tracking**: Each freelancer-job pair tracked separately, enabling individual cooloff timelines
- **Backward Compatibility**: Handles legacy string-format decisions by converting to new dictionary format
- **Market Learning**: Enables freelancers to apply strategy changes (rate adjustments, market learning) to previously declined opportunities
- **Research Benefit**: Studies long-term decision evolution, strategy adaptation, and market efficiency improvements from re-bidding opportunities

### 3.10 Enhanced Performance Optimizations ⚡ **NEWEST**
- **Parallelized API Requests**: All major bottlenecks use ThreadPoolExecutor for 3-5x speed improvements
  - Job posting generation (clients in parallel)
  - Bidding decisions (freelancers in parallel)  
  - Hiring decisions (client evaluations in parallel)
  - Job completions (completion evaluations in parallel)
- **Configurable Concurrency**: `--max-workers` parameter (default: 15) controls parallelization level
- **Quiet Mode Processing**: `--quiet` flag reduces logging verbosity for faster execution
- **Periodic Saves**: In quiet mode, saves results every 25 rounds instead of every round
- **Research Benefit**: Enables larger-scale experiments with reasonable execution times

### 3.11 Pure Ranking Relevance System ⚡ **NEWEST**
- **Threshold Elimination**: Removed all minimum score thresholds from job relevance calculations
- **Weighted Component Scoring**: Jobs ranked by combined skill + budget + timeline scores without arbitrary cutoffs
- **Natural Distribution**: All jobs receive meaningful relevance scores (0.0-1.0) enabling proper ranking
- **Configurable Weights**: Different relevance modes (strict, balanced, lenient) use different scoring weights
- **Research Benefit**: Studies natural job selection patterns without artificial threshold artifacts

### 3.12 Configurable Freelancer Capacity ⚡ **NEWEST**
- **Dynamic Max Active Jobs**: `--max-active-jobs` parameter controls freelancer concurrent project capacity
- **Default Conservative**: Default of 3 active jobs maintains realistic capacity constraints
- **Scaling Potential**: Higher limits (5-10) enable study of high-capacity freelancer behaviors
- **Capacity-Based Bidding**: Freelancers cannot bid when at active job capacity
- **Research Benefit**: Studies capacity constraints effects on market participation and reputation progression

### 3.13 Accelerated Project Completion ⚡ **NEWEST**
- **Reduced Duration**: Average project duration reduced from 8-18 rounds to 5 rounds average
- **Timeline Conversion**: Simplified mapping (1 month = 1 round, 1 week = 1 round minimum)
- **Faster Reputation Progression**: Enables meaningful tier advancement within reasonable simulation lengths
- **Increased Throughput**: More project completions per simulation enable richer reputation dynamics
- **Research Benefit**: Studies full reputation system lifecycle and multi-tier progression patterns

## 4. Economic and Financial Assumptions

### 4.1 No Inflation or Market Evolution
- **Assumption**: Wage levels, budgets, and pricing remain stable over time
- **Implication**: No learning about market rates, no adaptation to changing conditions
- **Justification**: Isolates behavioral effects from macroeconomic changes
- **Limitation**: Real markets show significant price evolution and learning

### 3.2 Perfect Budget Information
- **Assumption**: Job budgets are clearly stated and visible to all freelancers
- **Implication**: No price discovery process, no negotiation dynamics
- **Justification**: Focuses on decision-making given perfect information
- **Limitation**: Real markets often have hidden budgets and extensive negotiation

### 3.3 No Transaction Costs
- **Assumption**: No costs for bidding, no platform fees, no payment processing costs
- **Implication**: Pure competition without friction
- **Justification**: Focuses on core competitive dynamics
- **Limitation**: Real platforms have significant transaction costs affecting behavior

### 3.4 Binary Hiring Decisions
- **Assumption**: Each job hires exactly one freelancer or remains unfilled
- **Implication**: No partial hiring, no team formation, no collaborative projects
- **Justification**: Simplifies hiring analysis
- **Limitation**: Many real projects involve multiple freelancers or ongoing relationships

## 5. Information and Communication Assumptions

### 5.1 Perfect Job Information
- **Assumption**: Job descriptions, requirements, and budgets are complete and accurate
- **Implication**: No information asymmetries about job scope
- **Justification**: Focuses on skill matching rather than information discovery
- **Limitation**: Real jobs often have unclear requirements and scope creep

### 4.2 Limited Market Visibility
- **Assumption**: Freelancers only see a subset of available jobs per round (configurable limit)
- **Implication**: Creates realistic attention constraints
- **Justification**: Models realistic cognitive and time limitations
- **Strength**: More realistic than assuming perfect market visibility

### 4.3 No Direct Agent Communication
- **Assumption**: Agents don't communicate with each other except through official bid/hiring channels
- **Implication**: No coalition formation, no information sharing, no market manipulation
- **Justification**: Focuses on individual decision-making
- **Limitation**: Real markets have extensive networking and information sharing

### 4.4 Imperfect Competition Information
- **Assumption**: Freelancers don't know how many others are bidding on the same job
- **Implication**: Must make decisions under uncertainty
- **Justification**: Realistic modeling of competition uncertainty
- **Strength**: Captures real market uncertainty

## 6. Behavioral and Cognitive Assumptions

### 6.1 GPT as Rational Actors
- **Assumption**: GPT responses represent consistent, goal-oriented decision-making
- **Implication**: Agents have stable preferences and logical reasoning
- **Justification**: Models "ideally rational" agents for baseline analysis
- **Limitation**: Real humans have cognitive biases, emotions, and inconsistent preferences

### 5.2 Perfect Memory and Learning
- **Assumption**: Agents remember all past experiences perfectly (via reflection system)
- **Implication**: No forgetting, no memory limitations, perfect strategy adaptation
- **Justification**: Models optimal learning conditions
- **Limitation**: Real agents have memory constraints and imperfect learning

### 5.3 Single-Goal Optimization
- **Assumption**: Freelancers primarily optimize for hiring success; clients optimize for quality/value
- **Implication**: No complex multi-objective decisions, no personal preferences beyond work
- **Justification**: Focuses on core marketplace dynamics
- **Limitation**: Real agents have complex, multi-faceted goals and constraints

### 5.4 No Fatigue Effects on Performance
- **Assumption**: "Fatigued" freelancers still perform at the same level when hired
- **Implication**: Fatigue only affects bidding behavior, not work quality
- **Justification**: Separates participation effects from performance effects
- **Limitation**: Real fatigue affects both participation and performance

## 7. Technical and Implementation Assumptions

### 7.1 Deterministic Job Completion
- **Assumption**: Job completion times are calculated deterministically from timeline specifications
- **Implication**: No project delays, scope changes, or unexpected complications
- **Justification**: Focuses on marketplace dynamics rather than project management
- **Limitation**: Real projects have significant uncertainty and variability

### 6.2 Integrated Reputation System
- **Assumption**: Reputation is based on job completion success rates, not bidding success rates
- **Implementation**: Fully integrated `SimpleReputationManager` that tracks both freelancer and client reputations
- **Freelancer Metrics**: Job completion rate, total earnings, category expertise, tier progression (New → Established → Expert → Elite)
- **Client Metrics**: Hire success rate, total spend, average budget level, tier progression
- **Adaptive Behavior**: Reputation data is included in GPT prompts, enabling agents to adapt strategies based on marketplace standing
- **Real-time Updates**: Reputation updates during bidding (hired/rejected), job completion (success/failure), and job posting (filled/unfilled)
- **Implication**: Agents make decisions with awareness of their reputation status, creating realistic adaptation dynamics
- **Justification**: Focuses on performance outcomes that matter to clients; separates market participation from work quality
- **Enhancement**: Uses job completion rate (successful_jobs/total_jobs_hired) rather than hiring rate (hired/total_bids)
- **Limitation**: Real reputation systems include reviews, ratings, and complex social signals

### 6.3 Limited Skill Complexity
- **Assumption**: Skills are represented as lists of keywords with semantic matching
- **Implication**: No skill levels, certifications, or complex skill interactions
- **Justification**: Focuses on basic skill matching dynamics
- **Limitation**: Real skill markets have complex certification and experience hierarchies

### 6.4 No Platform Evolution
- **Assumption**: The marketplace platform itself doesn't change rules, features, or algorithms during simulation
- **Implication**: Focuses on agent adaptation rather than platform evolution
- **Justification**: Isolates agent behavior from platform effects
- **Limitation**: Real platforms constantly evolve features and policies

## 8. Market Dynamics Assumptions

### 8.1 No Network Effects
- **Assumption**: Agent success doesn't depend on network connections or referrals
- **Implication**: Pure merit-based competition
- **Justification**: Focuses on skill/price competition
- **Limitation**: Real markets have significant network and relationship effects

### 7.2 No Long-term Relationships
- **Assumption**: Each job is an independent transaction with no preference for repeat collaboration
- **Implication**: No relationship building, no client loyalty effects
- **Justification**: Focuses on spot market dynamics
- **Limitation**: Real markets develop long-term client relationships

### 7.3 Unlimited Job Supply
- **Assumption**: Clients can always generate new job postings (subject to cooldown)
- **Implication**: No demand constraints, no business cycle effects
- **Justification**: Focuses on supply-side (freelancer) dynamics
- **Limitation**: Real markets have varying demand levels and business cycles

### 7.4 No External Market Forces
- **Assumption**: No economic shocks, competitor platforms, or regulatory changes
- **Implication**: Closed system dynamics only
- **Justification**: Isolates internal marketplace effects
- **Limitation**: Real markets are affected by external economic and regulatory forces

## 9. Research and Analysis Assumptions

### 9.1 Observable Preferences
- **Assumption**: Agent preferences can be inferred from GPT reasoning text
- **Implication**: Assumes honest and complete reasoning disclosure
- **Justification**: Enables analysis of decision-making processes
- **Limitation**: Real agents may not disclose true reasoning or may not be fully self-aware

### 8.2 Measurable Outcomes
- **Assumption**: Success can be measured through hiring rates, completion rates, and simple metrics
- **Implication**: Focuses on quantifiable outcomes
- **Justification**: Enables statistical analysis and comparison
- **Limitation**: Real success includes many intangible factors

### 8.3 Comparable Across Conditions
- **Assumption**: Results from different parameter settings can be meaningfully compared
- **Implication**: Assumes consistent agent behavior across different market conditions
- **Justification**: Enables experimental research design
- **Limitation**: Real agent behavior may change qualitatively under different conditions

## 10. Implications for Research

### 10.1 What the Framework Can Study Well
- **Agent adaptation**: How individuals adjust strategies based on experience and reputation feedback
- **Market saturation**: Effects of supply/demand imbalances on job fill rates and competition
- **Information asymmetries**: Impact of limited job visibility on bidding decisions
- **Competition intensity**: Effects of bidding constraints and competition levels on market dynamics
- **Skill matching**: Quality of job-freelancer matching using semantic embeddings and pure ranking algorithms
- **Reputation dynamics**: How performance history affects marketplace opportunities and tier progression
- **Quality signaling**: How reputation tiers influence client hiring decisions and freelancer bidding strategies
- **Adaptive prompting**: How reputation awareness in GPT prompts affects decision-making
- **Behavioral emergence**: Unexpected patterns arising from agent interactions and reputation-based adaptations
- **Category specialization**: How freelancers develop expertise in specific job categories over time
- **Bid cooloff dynamics**: How re-bidding opportunities affect market efficiency and agent strategy evolution
- **Decision evolution**: Long-term patterns in how freelancers reconsider previously declined opportunities
- **Strategy adaptation**: Effects of market learning on subsequent bidding decisions for the same jobs
- **Capacity constraints**: How freelancer active job limits affect market participation and success patterns
- **Project lifecycle**: Complete reputation progression from New → Established → Expert → Elite tiers
- **Parameter sensitivity**: How framework settings create different emergent behaviors and market dynamics
- **Performance scaling**: Large-scale market simulations with hundreds of agents over extended periods
- **Binary decision outcomes**: Pure success/failure patterns in job completion and market evaluation
- **Natural ranking patterns**: Job selection behaviors without artificial threshold constraints

### 9.2 What the Framework Cannot Study
- **Market entry/exit dynamics**: No population changes
- **Network effects**: No relationship building or referrals
- **Complex project dynamics**: No scope changes, team formation, or long-term collaboration
- **Macroeconomic effects**: No inflation, business cycles, or external shocks
- **Platform evolution**: No changing rules or features
- **Real human psychology**: GPT approximates but doesn't replicate human decision-making

### 9.3 Recommended Research Interpretations
- **Treat as baseline**: Results show "idealized" rational agent behavior
- **Focus on relative effects**: Compare across conditions rather than absolute values
- **Look for emergent patterns**: Unexpected behaviors arising from agent interactions
- **Consider scope limitations**: Don't generalize beyond the modeled aspects
- **Use for hypothesis generation**: Identify patterns worthy of real-world testing

### 6.3 Historical Reputation Tracking

The framework now includes comprehensive **temporal reputation tracking** to enable longitudinal studies of agent adaptation:

**Implementation:**
- **Round-by-round snapshots**: Complete reputation state saved in each simulation round
- **Progression analysis**: Methods to analyze tier mobility, learning trajectories, and adaptation patterns
- **Temporal metrics**: Score improvements, completion rate changes, category expertise evolution
- **Adaptive behavior**: Agents receive reputation context in decision-making prompts

**Capabilities:**
- Track individual agent journeys from "New" to "Elite" tiers over time
- Measure learning curves and adaptation effectiveness
- Analyze how reputation affects hiring outcomes and bidding strategies
- Study market feedback loops between individual adaptation and collective dynamics

**Research Applications:**
- **Agent Learning Studies**: How do agents improve their performance over time?
- **Reputation Dynamics**: What role does reputation play in marketplace success?
- **Adaptation Patterns**: Which agents adapt successfully and why?
- **Market Evolution**: How do individual adaptations affect the broader market?

## 11. Future Enhancement Opportunities

### 11.1 Relaxable Assumptions
- **Population dynamics**: Add agent entry/exit based on success/frustration
- **Market evolution**: Add platform feature changes and rule updates
- **Relationship building**: Add repeat client preferences and network effects
- **Skill complexity**: Add skill levels, certifications, and learning curves
- **Economic dynamics**: Add inflation, market cycles, and external shocks

### 10.2 Validation Opportunities
- **Compare with real data**: Test whether patterns match actual marketplace data
- **Human subject studies**: Compare GPT decisions with human decisions
- **Platform partnerships**: Validate against real platform metrics
- **Longitudinal studies**: Historical reputation tracking enables multi-round adaptation studies

---

*This document should be updated as the framework evolves and new assumptions are identified or existing ones are relaxed.*
