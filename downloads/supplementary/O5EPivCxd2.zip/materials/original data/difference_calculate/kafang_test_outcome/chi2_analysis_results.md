# Chi-Square Analysis Results

Analysis performed on September 01, 2025, 12:50 AM +08.

## Analysis for A_size_only_001_rect.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for A_size_only_002_square.png
- **Human Data**: Correct = 3, Total = 5, Correct Ratio = 0.60
- **AI Data**: Correct = 1, Total = 50, Correct Ratio = 0.02
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 3 | 2 | 
  | 1 | 49 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 14.8891
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.36363636  4.63636364]
 [ 3.63636364 46.36363636]]
  - p-value = 0.0001
- **Fisher Exact Test** (one-sided): p-value = 0.0015

## Analysis for A_size_only_003_rect.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for A_size_only_004_circle.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 11, Total = 50, Correct Ratio = 0.22
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 11 | 39 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 9.8916
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 1.45454545  3.54545455]
 [14.54545455 35.45454545]]
  - p-value = 0.0017
- **Fisher Exact Test** (one-sided): p-value = 0.0013

## Analysis for A_size_only_005_circle.png
- **Human Data**: Correct = 3, Total = 5, Correct Ratio = 0.60
- **AI Data**: Correct = 10, Total = 50, Correct Ratio = 0.20
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 3 | 2 | 
  | 10 | 40 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 2.1179
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 1.18181818  3.81818182]
 [11.81818182 38.18181818]]
  - p-value = 0.1456
- **Fisher Exact Test** (one-sided): p-value = 0.0798

## Analysis for A_size_only_006_circle.png
- **Human Data**: Correct = 3, Total = 5, Correct Ratio = 0.60
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 3 | 2 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 21.1627
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.27272727  4.72727273]
 [ 2.72727273 47.27272727]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0004

## Analysis for A_size_only_007_rect.png
- **Human Data**: Correct = 3, Total = 5, Correct Ratio = 0.60
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 3 | 2 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 21.1627
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.27272727  4.72727273]
 [ 2.72727273 47.27272727]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0004

## Analysis for A_size_only_008_square.png
- **Human Data**: Correct = 4, Total = 5, Correct Ratio = 0.80
- **AI Data**: Correct = 1, Total = 50, Correct Ratio = 0.02
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 4 | 1 | 
  | 1 | 49 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 24.6895
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0001

## Analysis for A_size_only_009_circle.png
- **Human Data**: Correct = 4, Total = 5, Correct Ratio = 0.80
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 4 | 1 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 32.0901
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.36363636  4.63636364]
 [ 3.63636364 46.36363636]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for A_size_only_010_rect.png
- **Human Data**: Correct = 4, Total = 5, Correct Ratio = 0.80
- **AI Data**: Correct = 5, Total = 50, Correct Ratio = 0.10
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 4 | 1 | 
  | 5 | 45 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 11.5613
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.81818182  4.18181818]
 [ 8.18181818 41.81818182]]
  - p-value = 0.0007
- **Fisher Exact Test** (one-sided): p-value = 0.0017

## Analysis for B_color_only_001_square.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 45, Total = 50, Correct Ratio = 0.90
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 45 | 5 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 0.0000
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 4.54545455  0.45454545]
 [45.45454545  4.54545455]]
  - p-value = 1.0000
- **Fisher Exact Test** (one-sided): p-value = 0.6091

## Analysis for B_color_only_002_circle.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 40, Total = 50, Correct Ratio = 0.80
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 40 | 10 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 0.2475
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 4.09090909  0.90909091]
 [40.90909091  9.09090909]]
  - p-value = 0.6188
- **Fisher Exact Test** (one-sided): p-value = 0.3512

## Analysis for B_color_only_003_circle.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 50, Total = 50, Correct Ratio = 1.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 50 | 0 | 
- **Chi-Square Test Failed**: The internally computed table of expected frequencies has a zero element at (np.int64(0), np.int64(1)).
- **Fisher Exact Test** (one-sided): p-value = 1.0000

## Analysis for B_color_only_004_star.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 43, Total = 50, Correct Ratio = 0.86
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 43 | 7 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 0.0368
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 4.36363636  0.63636364]
 [43.63636364  6.36363636]]
  - p-value = 0.8478
- **Fisher Exact Test** (one-sided): p-value = 0.4922

## Analysis for B_color_only_005_triangle.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 30, Total = 50, Correct Ratio = 0.60
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 30 | 20 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 1.6520
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 3.18181818  1.81818182]
 [31.81818182 18.18181818]]
  - p-value = 0.1987
- **Fisher Exact Test** (one-sided): p-value = 0.0933

## Analysis for B_color_only_006_circle.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 48, Total = 50, Correct Ratio = 0.96
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 48 | 2 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 0.0000
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 4.81818182  0.18181818]
 [48.18181818  1.81818182]]
  - p-value = 1.0000
- **Fisher Exact Test** (one-sided): p-value = 0.8249

## Analysis for B_color_only_007_circle.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 49, Total = 50, Correct Ratio = 0.98
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 49 | 1 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 0.0000
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 4.90909091  0.09090909]
 [49.09090909  0.90909091]]
  - p-value = 1.0000
- **Fisher Exact Test** (one-sided): p-value = 0.9091

## Analysis for B_color_only_008_circle.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 42, Total = 50, Correct Ratio = 0.84
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 42 | 8 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 0.0914
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 4.27272727  0.72727273]
 [42.72727273  7.27272727]]
  - p-value = 0.7624
- **Fisher Exact Test** (one-sided): p-value = 0.4409

## Analysis for B_color_only_009_circle.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 41, Total = 50, Correct Ratio = 0.82
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 41 | 9 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 0.1627
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 4.18181818  0.81818182]
 [41.81818182  8.18181818]]
  - p-value = 0.6866
- **Fisher Exact Test** (one-sided): p-value = 0.3940

## Analysis for B_color_only_010_circle.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 40, Total = 50, Correct Ratio = 0.80
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 40 | 10 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 0.2475
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 4.09090909  0.90909091]
 [40.90909091  9.09090909]]
  - p-value = 0.6188
- **Fisher Exact Test** (one-sided): p-value = 0.3512

## Analysis for C_size_and_color_001_rect.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for C_size_and_color_002_square.png
- **Human Data**: Correct = 4, Total = 5, Correct Ratio = 0.80
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 4 | 1 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 32.0901
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.36363636  4.63636364]
 [ 3.63636364 46.36363636]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for C_size_and_color_003_circle.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for C_size_and_color_004_triangle.png
- **Human Data**: Correct = 4, Total = 5, Correct Ratio = 0.80
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 4 | 1 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 32.0901
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.36363636  4.63636364]
 [ 3.63636364 46.36363636]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for C_size_and_color_005_square.png
- **Human Data**: Correct = 4, Total = 5, Correct Ratio = 0.80
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 4 | 1 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 32.0901
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.36363636  4.63636364]
 [ 3.63636364 46.36363636]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for C_size_and_color_006_circle.png
- **Human Data**: Correct = 4, Total = 5, Correct Ratio = 0.80
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 4 | 1 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 32.0901
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.36363636  4.63636364]
 [ 3.63636364 46.36363636]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for C_size_and_color_007_triangle.png
- **Human Data**: Correct = 3, Total = 5, Correct Ratio = 0.60
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 3 | 2 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 21.1627
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.27272727  4.72727273]
 [ 2.72727273 47.27272727]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0004

## Analysis for C_size_and_color_008_rect.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for C_size_and_color_009_triangle.png
- **Human Data**: Correct = 4, Total = 5, Correct Ratio = 0.80
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 4 | 1 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 32.0901
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.36363636  4.63636364]
 [ 3.63636364 46.36363636]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for C_size_and_color_010_square.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for birds01.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 10, Total = 50, Correct Ratio = 0.20
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 10 | 40 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 10.9106
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 1.36363636  3.63636364]
 [13.63636364 36.36363636]]
  - p-value = 0.0010
- **Fisher Exact Test** (one-sided): p-value = 0.0009

## Analysis for birds02.png
- **Human Data**: Correct = 4, Total = 5, Correct Ratio = 0.80
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 4 | 1 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 32.0901
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.36363636  4.63636364]
 [ 3.63636364 46.36363636]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for birds03.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 9, Total = 50, Correct Ratio = 0.18
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 9 | 41 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 12.0756
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 1.27272727  3.72727273]
 [12.72727273 37.27272727]]
  - p-value = 0.0005
- **Fisher Exact Test** (one-sided): p-value = 0.0006

## Analysis for birds04.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for birds05.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 20, Total = 50, Correct Ratio = 0.40
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 20 | 30 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 4.4018
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 2.27272727  2.72727273]
 [22.72727273 27.27272727]]
  - p-value = 0.0359
- **Fisher Exact Test** (one-sided): p-value = 0.0153

## Analysis for birds06.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for birds07.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 7, Total = 50, Correct Ratio = 0.14
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 7 | 43 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 14.9891
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 1.09090909  3.90909091]
 [10.90909091 39.09090909]]
  - p-value = 0.0001
- **Fisher Exact Test** (one-sided): p-value = 0.0002

## Analysis for birds08.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 13, Total = 50, Correct Ratio = 0.26
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 13 | 37 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 8.1943
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 1.63636364  3.36363636]
 [16.36363636 33.63636364]]
  - p-value = 0.0042
- **Fisher Exact Test** (one-sided): p-value = 0.0025

## Analysis for birds09.png
- **Human Data**: Correct = 3, Total = 5, Correct Ratio = 0.60
- **AI Data**: Correct = 18, Total = 50, Correct Ratio = 0.36
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 3 | 2 | 
  | 18 | 32 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 0.3255
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 1.90909091  3.09090909]
 [19.09090909 30.90909091]]
  - p-value = 0.5683
- **Fisher Exact Test** (one-sided): p-value = 0.2788

## Analysis for birds10.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 1, Total = 50, Correct Ratio = 0.02
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 1 | 49 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 35.3992
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.54545455  4.45454545]
 [ 5.45454545 44.54545455]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for hands01.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for hands02.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 22, Total = 50, Correct Ratio = 0.44
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 22 | 28 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 3.6830
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 2.45454545  2.54545455]
 [24.54545455 25.45454545]]
  - p-value = 0.0550
- **Fisher Exact Test** (one-sided): p-value = 0.0232

## Analysis for hands03.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 4, Total = 50, Correct Ratio = 0.08
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 4 | 46 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 21.7908
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.81818182  4.18181818]
 [ 8.18181818 41.81818182]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for hands04.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for hands05.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 31, Total = 50, Correct Ratio = 0.62
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 31 | 19 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 1.4655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 3.27272727  1.72727273]
 [32.72727273 17.27272727]]
  - p-value = 0.2261
- **Fisher Exact Test** (one-sided): p-value = 0.1084

## Analysis for hands06.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for hands07.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 12, Total = 50, Correct Ratio = 0.24
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 12 | 38 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 8.9928
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 1.54545455  3.45454545]
 [15.45454545 34.54545455]]
  - p-value = 0.0027
- **Fisher Exact Test** (one-sided): p-value = 0.0018

## Analysis for hands08.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

## Analysis for hands09.png
- **Human Data**: Correct = 4, Total = 5, Correct Ratio = 0.80
- **AI Data**: Correct = 35, Total = 50, Correct Ratio = 0.70
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 4 | 1 | 
  | 35 | 15 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 0.0000
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 3.54545455  1.45454545]
 [35.45454545 14.54545455]]
  - p-value = 1.0000
- **Fisher Exact Test** (one-sided): p-value = 0.5438

## Analysis for hands10.png
- **Human Data**: Correct = 5, Total = 5, Correct Ratio = 1.00
- **AI Data**: Correct = 0, Total = 50, Correct Ratio = 0.00
- **Contingency Table**:
  | Human Correct | Human Incorrect | 
  |---------------|-----------------| 
  | 5 | 0 | 
  | 0 | 50 | 
- **Chi-Square Test**:
  - Chi-Square Statistic = 43.5655
  - Degrees of Freedom = 1
  - Expected Frequencies = [[ 0.45454545  4.54545455]
 [ 4.54545455 45.45454545]]
  - p-value = 0.0000
- **Fisher Exact Test** (one-sided): p-value = 0.0000

