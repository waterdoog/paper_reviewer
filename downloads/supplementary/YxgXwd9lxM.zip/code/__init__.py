# QISK: Quantum-Inspired Streaming Kernels
# Copyright (c) 2025 QISK Contributors

__version__ = "1.0.0"
__author__ = "QISK Contributors"

from .qisk_implementation import QISK
from .physically_correct_quantum_kernel import QuantumInspiredKernel
from .real_world_datasets import get_real_world_datasets

__all__ = ['QISK', 'QuantumInspiredKernel', 'get_real_world_datasets']