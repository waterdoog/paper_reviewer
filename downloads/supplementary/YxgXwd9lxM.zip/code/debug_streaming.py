#!/usr/bin/env python
"""Debug streaming experiment to see why QISK gets 50% accuracy."""

import numpy as np
from simple_qisk_wrapper import create_enhanced_qisk
from real_world_datasets import get_dataset_by_name
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

# Replicate the streaming experiment setup
print("🔍 Debugging streaming experiment...")

# Use same parameters as run_streaming_experiments.py
window_size = 100
n_windows = 5  # Just test first 5 windows

dataset = get_dataset_by_name('sea', n_samples=5000, 
                              drift_points=[1500, 3000, 4000],
                              noise_level=0.05)

print(f"Dataset features: {dataset.n_features}")

stream_data = list(dataset.stream())
print(f"Stream data length: {len(stream_data)}")

qisk = create_enhanced_qisk()
svm_baseline = SVC(kernel='rbf', C=1.0, gamma='scale')

qisk_accuracies = []
svm_accuracies = []

for window_idx in range(n_windows):
    print(f"\n--- Window {window_idx} ---")
    
    # Get current window data (replicate exact logic)
    start_idx = window_idx * window_size
    end_idx = min((window_idx + 1) * window_size, len(stream_data))
    
    window_data = stream_data[start_idx:end_idx]
    X_window = np.array([x for x, y in window_data])
    y_window = np.array([y for x, y in window_data])
    
    print(f"Window data shape: X {X_window.shape}, y {y_window.shape}")
    print(f"Window labels: {np.unique(y_window, return_counts=True)}")
    
    if len(X_window) < 10:
        print(f"Skipping - too few samples: {len(X_window)}")
        continue
        
    # Split window into train/test (replicate exact logic)
    split_point = len(X_window) // 2
    X_train, X_test = X_window[:split_point], X_window[split_point:]
    y_train, y_test = y_window[:split_point], y_window[split_point:]
    
    print(f"Split: train {X_train.shape}, test {X_test.shape}")
    print(f"Train labels: {np.unique(y_train, return_counts=True)}")
    print(f"Test labels: {np.unique(y_test, return_counts=True)}")
    
    if len(np.unique(y_train)) < 2:
        print("Skipping - not enough classes in training")
        continue
    
    try:
        # Test QISK (replicate exact logic)
        if window_idx == 0:
            # Initial fitting
            qisk.fit(X_train, y_train)
        else:
            # Adaptive update using partial_fit
            qisk.partial_fit(X_train, y_train)
        
        qisk_pred = qisk.predict(X_test)
        qisk_acc = accuracy_score(y_test, qisk_pred)
        qisk_accuracies.append(qisk_acc)
        print(f"QISK accuracy: {qisk_acc:.3f}")
        
        # Test SVM baseline
        svm_baseline.fit(X_train, y_train)
        svm_pred = svm_baseline.predict(X_test)
        svm_acc = accuracy_score(y_test, svm_pred)
        svm_accuracies.append(svm_acc)
        print(f"SVM accuracy: {svm_acc:.3f}")
        
        # Debug predictions
        print(f"QISK preds (first 10): {qisk_pred[:10]}")
        print(f"True labels (first 10): {y_test[:10]}")
        print(f"SVM preds (first 10): {svm_pred[:10]}")
        
    except Exception as e:
        print(f"Error in window {window_idx}: {e}")

print(f"\nFinal results:")
print(f"QISK accuracies: {qisk_accuracies}")
print(f"SVM accuracies: {svm_accuracies}")
print(f"QISK mean: {np.mean(qisk_accuracies):.3f}")
print(f"SVM mean: {np.mean(svm_accuracies):.3f}")

# Check if QISK is returning random predictions
if qisk_accuracies:
    all_close_to_05 = all(abs(acc - 0.5) < 0.1 for acc in qisk_accuracies)
    print(f"QISK predictions close to random: {all_close_to_05}")