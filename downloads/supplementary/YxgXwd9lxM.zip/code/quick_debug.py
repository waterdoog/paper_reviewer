#!/usr/bin/env python
"""Quick debug - run just one window."""

import sys
sys.path.append('.')

from run_streaming_experiments import StreamingExperimentRunner
from real_world_datasets import get_dataset_by_name

runner = StreamingExperimentRunner(window_size=100, n_windows=2)  # Just 2 windows

dataset = get_dataset_by_name('sea', n_samples=5000, 
                              drift_points=[1500, 3000, 4000],
                              noise_level=0.05)

print("Running single window test...")
accuracies = runner.run_method_on_stream('qisk', dataset, seed=42)
print(f"QISK accuracies: {accuracies}")

# Also test baseline
svm_accuracies = runner.run_method_on_stream('rbf_svm_standard', dataset, seed=42)
print(f"SVM accuracies: {svm_accuracies}")