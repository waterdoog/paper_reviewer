# QISK: Quantum-Inspired Streaming Kernels - Submission Package

This package contains the complete submission for the paper:

**"QISK: Quantum-Inspired Streaming Kernels for Robust Classification under Concept Drift"**

## Directory Structure

```
├── paper/                          # Paper, bibliography, and figures
│   ├── qisk_agents4science.pdf     # Final compiled paper
│   ├── qisk_agents4science.tex     # LaTeX source
│   ├── references.bib              # Bibliography (27 entries)
│   ├── agents4science_2025.sty     # Conference style file
│   ├── performance_comparison.pdf        # Main results comparison
│   ├── window_performance_timeseries.pdf # Performance over time
│   ├── performance_comparison_final.pdf  # Final comparison chart
│   ├── results_table_final.pdf          # Results table
│   └── improvement_summary.pdf          # QISK improvements
│
├── code/                          # Implementation and experiments
│   ├── qisk_implementation.py     # Main QISK algorithm
│   ├── physically_correct_quantum_kernel.py  # Quantum kernels
│   ├── alignment_utils.py         # KTA computation utilities
│   ├── dro_utils.py              # DRO-Lite importance weighting
│   ├── anchor_utils.py           # Drift-aware anchor refresh
│   ├── enhanced_baselines.py     # Advanced baseline methods
│   ├── evaluation_protocols.py   # Evaluation framework
│   ├── experiments/              # Experiment runners
│   ├── baselines/                # Baseline implementations
│   └── tests/                    # Unit tests
│
├── data/                         # Experimental results
│   └── experimental_results/     # JSON results and metadata
│
├── requirements.txt              # Python dependencies
├── reproduce.sh                  # Reproduction script
└── LICENSE                       # MIT license
```

## Quick Start

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Reproduce ALL results and figures:**
   ```bash
   bash reproduce.sh
   ```
   This will:
   - Generate experimental results
   - Create all publication figures
   - Copy figures to paper directory
   - Verify paper compilation readiness

3. **Generate figures only:**
   ```bash
   cd code
   python generate_all_figures.py
   ```

4. **Compile paper:**
   ```bash
   cd paper
   pdflatex qisk_agents4science.tex
   bibtex qisk_agents4science
   pdflatex qisk_agents4science.tex
   pdflatex qisk_agents4science.tex
   ```

   All required files (LaTeX source, bibliography, style file, and figures) are in the `paper/` directory for easy compilation.

## Core Algorithm Files

- **`code/qisk_implementation.py`**: Main QISK algorithm implementation
- **`code/physically_correct_quantum_kernel.py`**: Quantum-inspired kernel functions
- **`code/alignment_utils.py`**: Centered weighted kernel-target alignment
- **`code/dro_utils.py`**: ESS-adaptive importance weighting (DRO-Lite)
- **`code/anchor_utils.py`**: Drift-aware anchor refresh for streaming Nyström

## Figure Reproduction

**✅ Complete Figure Reproduction Pipeline**

The `code/generate_all_figures.py` script reproduces ALL figures used in the paper:

**Main Paper Figures:**
- **performance_comparison.pdf**: Figure 1 - Method comparison across datasets
- **window_performance_timeseries.pdf**: Figure 2 - Performance over time with drift points

**Additional Analysis Figures:**
- **results_table.pdf**: Results table
- **improvement_summary.pdf**: QISK improvement analysis

**Key Features:**
- ✅ Generates figures directly from experimental results
- ✅ Creates both primary and alternative versions for compatibility
- ✅ Automatically copies figures to paper directory
- ✅ Publication-quality formatting (300 DPI, proper fonts)
- ✅ Reproduces exact figures used in the paper

## Experimental Results

The `data/experimental_results/` directory contains:
- `comprehensive_results.json`: Complete experimental results
- Performance metrics for all methods across datasets
- Statistical significance tests and confidence intervals

## Key Features

✅ **Robust Performance**: Consistent worst-window accuracy under concept drift  
✅ **Computational Efficiency**: O(nm²) complexity with streaming Nyström  
✅ **No Quantum Hardware**: Entirely classical implementation  
✅ **Comprehensive Baselines**: Fair comparison with advanced methods  
✅ **Statistical Rigor**: Multi-seed evaluation with confidence intervals

## Citation

```bibtex
@article{qisk_2024,
  title={QISK: Quantum-Inspired Streaming Kernels for Robust Classification under Concept Drift},
  author={Anonymous Authors},
  journal={Agents4Science Workshop},
  year={2024}
}
```

## License

MIT License - see LICENSE file for details.