#!/bin/bash

echo "🚀 QISK Paper Reproduction Pipeline"
echo "===================================="

# Install dependencies
echo "📦 Installing dependencies..."
pip install -r requirements.txt

# Run the complete reproduction pipeline
echo "🔄 Running complete reproduction..."
python reproduce_all.py

echo ""
echo "✅ QISK reproduction complete!"
echo ""
echo "📋 Generated files:"
echo "  📊 Experimental results: data/experimental_results/"
echo "  🎨 All figures: code/figures/ and paper/"
echo "  📄 Ready for paper compilation in paper/"
echo ""
echo "🏃‍♂️ To compile the paper:"
echo "  cd paper"
echo "  pdflatex qisk_agents4science.tex"
echo "  bibtex qisk_agents4science"  
echo "  pdflatex qisk_agents4science.tex"
echo "  pdflatex qisk_agents4science.tex"