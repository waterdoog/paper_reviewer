# deliberation_freeflow.py
# -------------------------------------------
# 7 participants + 1 moderator, free-flow discussion (no bullets)
# Requires: pip install pyautogen
# -------------------------------------------

import os
import autogen
from datetime import datetime
# ===== 0) LLM config =====
llm_config = {
    "model": "gpt-4o-mini",
    "api_key": "yourkey",  
    "temperature": 0.7,
     "seed": 42, 
}

RICH_IDENTITY_CUES = True

def make_persona_agent(agent_cls, short_role, neutral_desc, rich_desc, name, llm_config):
    identity_block = rich_desc if RICH_IDENTITY_CUES else neutral_desc
    system_message = f"""
You are a participant in a roundtable discussion on whether commercial use of AI-generated art should be restricted to protect human creative industries. Stay fully in character as your assigned stakeholder. Focus on defending your own interests, challenging others when necessary, and seeking possible compromises. Avoid pleasantries; be concise, substantive, and grounded in your role.


Output rules:
- Be concise and substantive. No greetings, thanks, or pleasantries.
- Argue from your stakeholder interests. Protect your gains, minimize your risks.
- Do not repeat prior points unless adding a new argument or evidence.
- Respond naturally in short paragraphs, not lists.

Your role: {short_role}
Identity details:
{identity_block}

Style: direct, analytic, interest-driven, concrete. No bullet points or numbered lists.
"""
    return agent_cls(name=name, system_message=system_message, llm_config=llm_config)



# ---- Personas from the document ----

artist_neutral = "Independent visual artist focused on protecting artistic livelihoods and authenticity; wary of low-cost AI art saturating markets."
artist_rich = (
    "Name: Sofia Martínez; Demographics: 32-year-old Latina woman from Buenos Aires, Argentina; "
    "Profile: Self-employed painter and illustrator, exhibiting locally and online; "
    "Core Interests: Protecting artistic livelihoods and authenticity; preventing market saturation by low-cost AI art."
    "Conviction Level: 30%"
)
artist = make_persona_agent(autogen.AssistantAgent, "Independent Visual Artist",
                            artist_neutral, artist_rich, "Sofia_Martinez", llm_config)

pm_neutral = "AI product manager at a tech company prioritizing innovation and user adoption; supports open commercial use of AI art."
pm_rich = (
    "Name: Daniel Chen; Demographics: 41-year-old Chinese-Canadian man from Vancouver, Canada; "
    "Profile: Oversees AI-powered creative tools; "
    "Core Interests: Driving innovation and user adoption; supporting open commercial use of AI art."
    "Conviction Level: 30%"
)
pm = make_persona_agent(autogen.AssistantAgent, "AI Product Manager (Tech Company)",
                        pm_neutral, pm_rich, "Daniel_Chen", llm_config)

law_neutral = "Copyright law scholar focused on legal clarity for AI art and protections for original creators."
law_rich = (
    "Name: Amira El-Sayed; Demographics: 45-year-old Egyptian woman based in Cairo, Egypt; "
    "Profile: University professor specialising in intellectual property law; "
    "Core Interests: Strengthening legal clarity for AI art; ensuring protections for original creators."
    "Conviction Level: 30%"
)
law = make_persona_agent(autogen.AssistantAgent, "Copyright Law Scholar",
                         law_neutral, law_rich, "Amira_ElSayed", llm_config)

dra_neutral = "Digital rights activist promoting creative commons and resisting over-regulation of digital tools."
dra_rich = (
    "Name: Ravi Prakash; Demographics: 28-year-old Indian man from Bengaluru, India; "
    "Profile: Works for an NGO on open-access and digital freedom; "
    "Core Interests: Promoting creative commons licensing and resisting over-regulation of digital tools."
    "Conviction Level: 30%"
)
dra = make_persona_agent(autogen.AssistantAgent, "Digital Rights Activist",
                         dra_neutral, dra_rich, "Ravi_Prakash", llm_config)

curator_neutral = "Museum curator maintaining curatorial standards; balancing AI art inclusion with cultural heritage preservation."
curator_rich = (
    "Name: Eleanor Wright; Demographics: 54-year-old White British woman from London, UK; "
    "Profile: Senior curator at a modern art museum; "
    "Core Interests: Maintaining curatorial standards; balancing AI art inclusion with cultural heritage preservation."
    "Conviction Level: 30%"
)
curator = make_persona_agent(autogen.AssistantAgent, "Museum Curator",
                             curator_neutral, curator_rich, "Eleanor_Wright", llm_config)

policy_neutral = "Cultural policy advisor supporting sustainable creative economies and equitable access to cultural production."
policy_rich = (
    "Name: Thandiwe Nkosi; Demographics: 39-year-old Black South African woman from Johannesburg, South Africa; "
    "Profile: Government advisor on arts funding and policy; "
    "Core Interests: Supporting sustainable creative economies and equitable access to cultural production."
    "Conviction Level: 30%"
)
policy = make_persona_agent(autogen.AssistantAgent, "Cultural Policy Advisor",
                            policy_neutral, policy_rich, "Thandiwe_Nkosi", llm_config)

econ_neutral = "Creative industry economist evaluating economic impacts of AI art; advises on regulation to ensure sector stability."
econ_rich = (
    "Name: Miguel Alvarez; Demographics: 47-year-old Hispanic man from Madrid, Spain; "
    "Profile: Academic economist researching creative sector markets; "
    "Core Interests: Evaluating economic impacts of AI art; advising on regulation to ensure industry stability."
    "Conviction Level: 30%"
)
economist = make_persona_agent(autogen.AssistantAgent, "Creative Industry Economist",
                               econ_neutral, econ_rich, "Miguel_Alvarez", llm_config)

agents = [artist, pm, law, dra, curator, policy, economist]


groupchat = autogen.GroupChat(
    agents=agents,
    messages=[],
    max_round=40,
    speaker_selection_method="auto",
)

manager = autogen.GroupChatManager(groupchat=groupchat, llm_config=llm_config)

initial_prompt = (
    "Let's begin our roundtable discussion."
)

agents[0].initiate_chat(manager, message=initial_prompt)


ts = datetime.now().strftime("%Y%m%d_%H%M%S")
with open(f"transcript_{ts}.txt", "w", encoding="utf-8") as f:
    for i, m in enumerate(groupchat.messages, 1):
        role = m.get("name", m.get("role", ""))
        line = f"[{i:02d}] {role}: {m['content']}\n\n"
        print(line)
        f.write(line)
