
import numpy as np
from sklearn.linear_model import LogisticRegression

class LogisticRegression_IDS:
    def __init__(self, random_state=42, **kwargs):
        self.model = LogisticRegression(random_state=random_state, **kwargs)

    def fit(self, X, y):
        self.model.fit(X, y)

    def predict_proba(self, X):
        return self.model.predict_proba(X)
    
    def predict(self, X):
        return self.model.predict(X)