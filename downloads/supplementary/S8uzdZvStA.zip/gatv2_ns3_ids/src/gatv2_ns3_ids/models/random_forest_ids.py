
import numpy as np
from sklearn.ensemble import RandomForestClassifier

class RandomForest_IDS:
    def __init__(self, random_state=42, n_estimators=100, **kwargs):
        self.model = RandomForestClassifier(random_state=random_state, n_estimators=n_estimators, **kwargs)

    def fit(self, X, y):
        self.model.fit(X, y)

    def predict_proba(self, X):
        return self.model.predict_proba(X)
    
    def predict(self, X):
        return self.model.predict(X)