# Reproducibility Statement — Submission #272 (Agents4Science 2025)

**Title:** Uncertainty-Guided Agents for Rare-Disease Hypothesis Discovery on Knowledge Graphs  
**Anonymity:** Preserved (no author-identifying info in this file)  
**Last updated:** 2025-09-25 04:24 UTC  

## Environment
- Python 3.10+, CPU-only
- Install: `pip install -r requirements.txt`
- Determinism: fixed seeds + stable `hashlib.md5`-based hashing (no salted `hash()`)

## How to reproduce
```bash
bash scripts/reproduce.sh
# or
python code/run_experiments.py --random-seed 123 --results-dir results/
```

## Expected outputs
- `results/metrics.json` (AUROC, AUPRC, Hit@10)
- `results/predictions.csv`
- `results/tables/*.csv`

## Notes
Synthetic KG only; no PII; figures map to CSVs in `results/tables/`.
