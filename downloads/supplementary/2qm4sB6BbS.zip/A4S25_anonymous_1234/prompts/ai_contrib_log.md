2025-09-15: AI generated research outline, code, figures, LaTeX draft.
Human validated content.
