# Results Summary

This artifact is reproducible; metrics below are produced by `python code/run_experiments.py --random-seed 42`.

- **AUROC**: 0.503
- **AUPRC**: 0.505
- **Hit@10**: 0.102

All tables in `results/tables/` and `results/predictions.csv` are synchronized with these numbers.
