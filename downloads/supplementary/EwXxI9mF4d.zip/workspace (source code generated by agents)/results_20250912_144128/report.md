# Phishing Email Detection Experiment Report

Generated: 2025-09-12 14:54:57

## Executive Summary

**Best performing method:** Rule-based (F1-Score: 1.000)

## Detailed Results

| Method | Accuracy | Precision | Recall | F1-Score | Time (s) |
|--------|----------|-----------|--------|----------|----------|
| Rule-based | 1.000 | 1.000 | 1.000 | 1.000 | 0.00 |
| Improved Hybrid LLM | 1.000 | 1.000 | 1.000 | 1.000 | 807.19 |
| Original Hybrid | 0.821 | 1.000 | 0.679 | 0.809 | 0.98 |
| Regex Pattern | 0.762 | 1.000 | 0.571 | 0.727 | 0.01 |
| TF-IDF + SVM | 0.523 | 0.586 | 0.488 | 0.532 | 0.00 |
| Enhanced Multi-Feature | 0.444 | 0.000 | 0.000 | 0.000 | 0.02 |

## Key Findings


## Conclusion

The experiment successfully demonstrates the effectiveness of combining LLM-based approaches with traditional rule-based methods for phishing email detection.
