## Reproducibility Statement

All data, code, and computational workflows underlying this study are fully reproducible and have been made available in the supplementary materials. Specifically, we provide:
* Raw Data Sources – Metadata tables listing all 17 scRNA-seq datasets downloaded from CellXGene with dataset IDs, doi, and tissue/cell-type annotations to ensure transparency of data acquisition.
* Analysis Scripts – All scripts used for preprocessing, scVI integration, SCENIC, consensus NMF (cNMF), network inference, and downstream visualization are included, exactly as executed by the agent system.
* Agent Chat Records – Complete chat memory with the Claude agent documents every analysis step, parameter choice, and iteration, providing full provenance for computational decisions.