# Introduction (Agent-updated)

This section is maintained by the Writing Agent using SPEC.WRITING.INTRO and gated by Reviewer Agent. Claims must reflect current results and pass gates G1–G5.

- Do not assert architecture superiority unless H2 gate is met.
- Cite only sources present in supplemental/reference lists.
