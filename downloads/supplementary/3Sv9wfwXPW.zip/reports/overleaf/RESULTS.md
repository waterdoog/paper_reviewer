# Results (Agent-updated)

Owned by Execution → Writing → Reviewer. Only report metrics that pass gates:

- Primary metrics: Y2 APE, 5y MAPE, Peak APE (≤5y), 80% PI coverage
- Include bootstrap 95% CIs and multiple-comparison adjustments
- Backtesting figures/tables with run IDs and provenance links
