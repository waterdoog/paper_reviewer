# AI-Powered Commercial Forecast Agent
# Core package for pharmaceutical forecasting models
