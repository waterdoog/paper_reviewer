# Load required libraries
library(dplyr)

# Gene information for the highlighted genes
gene_info <- data.frame(
  Entrez_ID = c("4329", "5290", "4534"),
  Gene_Symbol = c("NDUFV2", "PIK3CA", "MTM1"),
  Gene_Name = c("NADH:ubiquinone oxidoreductase subunit V2", 
                "phosphatidylinositol-4,5-bisphosphate 3-kinase catalytic subunit alpha",
                "myotubularin 1"),
  stringsAsFactors = FALSE
)

print("Information about highlighted genes:")
print(gene_info)

# Check if files are in the right location
print("\n=== Checking file locations ===")
current_files <- list.files("/workdir/execution_outputs", pattern = "hsa00562", full.names = TRUE)
print("Files in execution_outputs directory:")
print(current_files)

# Create a summary report
cat("\n=== PATHWAY VISUALIZATION SUMMARY ===\n")
cat("Pathway: hsa00562 (Inositol phosphate metabolism)\n")
cat("Highlighted genes (shown in red):\n")
for(i in 1:nrow(gene_info)) {
  cat(sprintf("  - %s (%s): %s\n", 
              gene_info$Entrez_ID[i], 
              gene_info$Gene_Symbol[i], 
              gene_info$Gene_Name[i]))
}
cat("\nOutput file: hsa00562.highlighted_genes.png\n")
cat("Location: /workdir/execution_outputs/\n")
cat("\nThe visualization shows the specified genes highlighted in red on the")
cat("\nInositol phosphate metabolism pathway, with all other genes in grey.\n")