import requests

# Session to persist cookies
session = requests.Session()

# Step 1: Login
login_url = "https://www.juniorgolfscoreboard.com/login-rankings.asp"
login_payload = {
    "custom_id": "<c_id>",
    "custom_password": "<password>",
    # include any other hidden form fields here
}

headers = {
    "User-Agent": "Mozilla/5.0",
}

response = session.post(login_url, data=login_payload, headers=headers)

# Step 2: Access protected page
protected_url = "https://www.juniorgolfscoreboard.com/junior-golf-rankings-display.asp"
protected_response = session.get(protected_url)

# Step 3: Save to file
with open("protected_page.html", "w", encoding='utf-8') as f:
    f.write(protected_response.text)
