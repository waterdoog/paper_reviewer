We haved PINNs to solve a Burger equation in 2 dimensions for a fixed value of the viscosity with multihead set for different initial conditions. The latent space is located in this file /Users/fanonymous/Documents/Software/AstroPilot/Project_turbulence/data_for_Paco_turbulence_bundle.npy


To read the data, you can do:

```python
import numpy  as np
fin = '/Users/fanonymous/Documents/Software/AstroPilot/Project_turbulenceV1/data_for_Paco_turbulence_bundle.npy'
data = np.load(fin)
```

data is now a [101,103,25,13] matrix, where the first axis represents the x-coordinate, the second axis is time, and the third component represents the viscosity. The forth axis is organized as follows:
- first three components are the mesh of space, time and the viscosity, respectively
- the rest (10 last components) the latent space

Perform a detailed study of the latent space structure. We are interested in knowing if there is some pattern or simple way to describe its properties.

