# How to run LoCoOp in Docker

Install LoCoOp related packages
```bash
pip install -r requirement.txt
```

Then run:
```bash
CUDA_VISIBLE_DEVICES=0 python baseline.py --output-dir results/ 
```
(Specifying CUDA_VISIBLE_DEVICES= is essential, otherwise it will be extremely slow.)

For plotting, you can run:
```bash
python plot.py --input-file results/scores.npz --output-dir results/baseline_plot
```
