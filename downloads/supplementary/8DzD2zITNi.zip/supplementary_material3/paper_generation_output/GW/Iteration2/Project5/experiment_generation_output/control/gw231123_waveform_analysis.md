<!-- filename: gw231123_waveform_analysis.md -->
### Results and Interpretation

The analysis of the gravitational-wave event GW231123 using five distinct waveform models reveals significant, physically-interpretable discrepancies in the inferred astrophysical parameters. This section details these findings, beginning with a baseline comparison of posterior distributions, moving to a high-dimensional analysis of parameter degeneracies, and culminating in a physics-informed decomposition of model disagreements to determine which properties of the source can be robustly constrained.

#### 1. Baseline Comparison: Significant Divergence in Key Physical Parameters

An initial comparison of the 1D marginal posterior distributions for key astrophysical parameters immediately highlights substantial disagreements between the waveform models. The summary statistics, presented in Table 1, quantify the range of inferred properties for GW231123.

**Table 1: Summary of Inferred Parameters**
This table shows the median and 90% credible interval (5th-95th percentiles) for key source parameters as inferred by each of the five waveform models.

| Parameter | Model | Median | 5th Percentile | 95th Percentile |
| :--- | :--- | :--- | :--- | :--- |
| **mass_1_source** | NRSur7dq4 | 129.14 | 115.15 | 143.86 |
|  | IMRPhenomXO4a | 143.18 | 128.70 | 167.47 |
|  | SEOBNRv5PHM | 133.69 | 119.69 | 152.28 |
|  | IMRPhenomXPHM | 149.87 | 138.24 | 162.34 |
|  | IMRPhenomTPHM | 133.37 | 121.44 | 150.75 |
| **mass_2_source** | NRSur7dq4 | 110.62 | 93.47 | 124.36 |
|  | IMRPhenomXO4a | 55.08 | 37.48 | 65.93 |
|  | SEOBNRv5pPHM | 111.10 | 91.61 | 127.56 |
|  | IMRPhenomXPHM | 93.33 | 73.44 | 111.44 |
|  | IMRPhenomTPHM | 110.04 | 95.16 | 125.21 |
| **chi_eff** | NRSur7dq4 | 0.23 | -0.12 | 0.48 |
|  | IMRPhenomXO4a | 0.30 | 0.15 | 0.50 |
|  | SEOBNRv5PHM | 0.44 | 0.21 | 0.63 |
|  | IMRPhenomXPHM | 0.04 | -0.17 | 0.19 |
|  | IMRPhenomTPHM | 0.44 | 0.27 | 0.58 |
| **chi_p** | NRSur7dq4 | 0.78 | 0.59 | 0.95 |
|  | IMRPhenomXO4a | 0.82 | 0.71 | 0.92 |
|  | SEOBNRv5PHM | 0.73 | 0.52 | 0.91 |
|  | IMRPhenomXPHM | 0.75 | 0.51 | 0.94 |
|  | IMRPhenomTPHM | 0.77 | 0.58 | 0.91 |
| **redshift** | NRSur7dq4 | 0.29 | 0.15 | 0.52 |
|  | IMRPhenomXO4a | 0.58 | 0.38 | 0.74 |
|  | SEOBNRv5PHM | 0.39 | 0.23 | 0.57 |
|  | IMRPhenomXPHM | 0.17 | 0.12 | 0.23 |
|  | IMRPhenomTPHM | 0.47 | 0.31 | 0.62 |
| **final_spin** | NRSur7dq4 | 0.81 | 0.67 | 0.87 |
|  | IMRPhenomXO4a | 0.85 | 0.78 | 0.90 |
|  | SEOBNRv5PHM | 0.87 | 0.81 | 0.92 |
|  | IMRPhenomXPHM | 0.71 | 0.61 | 0.77 |
|  | IMRPhenomTPHM | 0.89 | 0.84 | 0.92 |

The most striking discrepancy is in the component masses. While `NRSur7dq4`, `SEOBNRv5PHM`, and `IMRPhenomTPHM` infer a relatively symmetric system with `mass_2_source` > 110 M$_\odot$, `IMRPhenomXO4a` strongly prefers a highly asymmetric configuration with a median `mass_2_source` of only 55 M$_\odot$. This fundamental disagreement on the mass ratio has cascading effects on other parameters, such as the effective spin (`chi_eff`) and redshift. For `chi_eff`, the inferred median values span from near-zero (0.04 for `IMRPhenomXPHM`) to significantly positive (0.44 for `SEOBNRv5PHM` and `IMRPhenomTPHM`), a range that has profound implications for the astrophysical formation channels of the binary.

These disagreements are visually confirmed in the marginal posterior distributions plot (`marginal_posteriors_comparison_1_...png`). The posteriors for `IMRPhenomXO4a` and `IMRPhenomXPHM` are often systematically shifted relative to the other three models, which form a more cohesive group. For instance, in the `redshift` panel, `IMRPhenomXPHM` prefers a much closer source, while `IMRPhenomXO4a` places it significantly farther away. The pairwise Jensen-Shannon Divergence (JSD) and Wasserstein distance metrics quantify this divergence, with JSD values exceeding 0.6 for `mass_2_source` and `redshift` between certain model pairs, indicating almost complete non-overlap of the distributions.

#### 2. High-Dimensional Degeneracy and Model Clustering

To understand how these individual parameter disagreements relate to the full, high-dimensional posterior structure, we employed the UMAP dimensionality reduction technique. The resulting 2D embedding, shown in the plot `umap_final_embedding_3_...png`, provides a powerful visualization of the global relationships between the five model posteriors.

The UMAP projection reveals a clear and structured separation of the models, indicating that the discrepancies are not isolated to single parameters but are features of the complex, correlated posterior space. The models cluster into three distinct groups:
1.  **A Core Cluster:** `NRSur7dq4`, `SEOBNRv5PHM`, and `IMRPhenomTPHM`.
2.  **An Isolated Cluster:** `IMRPhenomXO4a`.
3.  **A Second Isolated Cluster:** `IMRPhenomXPHM`.

The centroids of these clusters in the UMAP space (see table below) quantify this separation. `IMRPhenomXPHM` is located in a completely different region of the embedding (`UMAP_1` ≈ -3.86), while `IMRPhenomXO4a` is also distinctly separate (`UMAP_1` ≈ 11.42). The core cluster, containing the NR-calibrated `NRSur7dq4`, the EOB model `SEOBNRv5PHM`, and the time-domain phenomenological model `IMRPhenomTPHM`, occupies a contiguous region, suggesting a greater degree of physical consistency among them.

**Table 2: UMAP Cluster Centroids**

| Model | UMAP_1 | UMAP_2 |
| :--- | :--- | :--- |
| IMRPhenomTPHM | 3.46 | 5.69 |
| IMRPhenomXO4a | 11.42 | 6.74 |
| IMRPhenomXPHM | -3.86 | -2.20 |
| NRSur7dq4 | -0.33 | 3.18 |
| SEOBNRv5PHM | 2.90 | 3.08 |

This structure is physically meaningful. The two most separated models, `IMRPhenomXO4a` and `IMRPhenomXPHM`, are both frequency-domain phenomenological models, but they employ different physics. `IMRPhenomXPHM` uses a "twisting-up" formalism for precession and is calibrated to a wide catalog of waveforms, while `IMRPhenomXO4a` has a more limited treatment of higher-order modes. The relative agreement within the core cluster suggests that for a high-mass, precessing system like GW231123, the time-domain models based on NR and EOB frameworks (`NRSur7dq4`, `SEOBNRv5PHM`) and the time-domain phenomenological model (`IMRPhenomTPHM`) capture more congruent physical dynamics.

#### 3. Physics-Informed Discrepancy Decomposition

To attribute these high-dimensional disagreements to specific physical effects, we calculated the multi-dimensional JSD between model pairs within four physically motivated parameter subspaces. The results, visualized as heatmaps in `subspace_jsd_heatmaps_4_...png`, provide a clear diagnosis of the sources of model discrepancy.

*   **Mass & Distance Subspace (`mass_1_source`, `mass_2_source`, `redshift`):** This subspace exhibits extremely high JSD values (many > 0.6), confirming that the models fundamentally disagree on the intrinsic masses and distance of the source. The disagreement is systemic, with nearly all model pairs showing significant divergence. This indicates that the way spin and orientation are modeled is strongly degenerate with the inferred masses and redshift, leading to large systematic shifts.

*   **Effective Spin Subspace (`chi_eff`, `chi_p`):** Discrepancies in this subspace are also large, particularly for pairs involving `IMRPhenomXPHM`. The JSD between `IMRPhenomXPHM` and `IMRPhenomTPHM` is 0.636, reflecting their opposing conclusions on `chi_eff`. This points directly to the different modeling of spin-orbit coupling and its impact on the inspiral rate. Notably, `SEOBNRv5PHM` and `IMRPhenomTPHM` show remarkable agreement in this subspace (JSD = 0.043), suggesting their modeling of orbit-averaged spin effects is highly consistent.

*   **Individual Spin & Orientation Subspace (`a_1`, `a_2`, `cos_tilt_1`, ...):** This 6-dimensional subspace shows the most severe and widespread disagreement, with JSD values approaching the theoretical maximum of ~0.693 for many pairs. This is a critical finding: the detailed, multi-dimensional configuration of the black hole spins and the binary's orientation is the most model-dependent aspect of the inference. This is the expected signature of differing treatments of spin precession, where the "twisting-up" formalisms of the phenomenological models diverge from the full dynamical evolution in the NR-calibrated and EOB models.

*   **Remnant Properties Subspace (`final_mass_source`, `final_spin`):** The inferred properties of the remnant black hole are also highly model-dependent. The JSD values are large, especially for pairs involving `IMRPhenomXPHM`, which predicts a much lower final spin. This suggests significant differences in the modeling of the merger-ringdown phase and the calibration to NR simulations. The close agreement between `SEOBNRv5PHM` and `IMRPhenomTPHM` (JSD = 0.051) is again notable, as both models include higher-order modes and appear to have a consistent description of the final state.

#### 4. Robust Astrophysical Inference for GW231123

The final step of our analysis was to synthesize these findings to determine which, if any, astrophysical parameters of GW231123 are robustly constrained across all five models. We defined a parameter as "robust" if the maximum pairwise JSD was below 0.05 and the relative range of median values was less than 10%.

**The primary conclusion of this work is that no key astrophysical parameter for GW231123 meets these criteria for robustness.** The systematic differences between waveform models are significant enough to preclude a single, consensus measurement for any of the analyzed properties. The final inference is summarized in Table 3.

**Table 3: Final Astrophysical Inference Summary for GW231123**

| Parameter | Status | Consensus Value | Physical Discrepancy Source |
| :--- | :--- | :--- | :--- |
| mass_1_source | Model-Dependent | 129.1 - 149.9 M$_\odot$ (Range) | Discrepancy linked to 'Mass & Distance' subspace. |
| mass_2_source | Model-Dependent | 55.1 - 111.1 M$_\odot$ (Range) | Discrepancy linked to 'Mass & Distance' subspace. |
| chi_eff | Model-Dependent | 0.04 - 0.44 (Range) | Discrepancy linked to 'Effective Spin' subspace. |
| chi_p | Model-Dependent | 0.73 - 0.82 (Range) | Discrepancy linked to 'Effective Spin' subspace. |
| redshift | Model-Dependent | 0.17 - 0.58 (Range) | Discrepancy linked to 'Mass & Distance' subspace. |
| final_mass_source | Model-Dependent | 189.7 - 232.7 M$_\odot$ (Range) | Discrepancy linked to 'Remnant Properties' subspace. |
| final_spin | Model-Dependent | 0.71 - 0.89 (Range) | Discrepancy linked to 'Remnant Properties' subspace. |

This result carries a crucial astrophysical insight: for high-mass, precessing binary black hole mergers like GW231123, where the signal is short and dominated by the highly non-linear merger and ringdown phases, systematic errors arising from waveform model choice can be comparable to, or even exceed, the statistical uncertainties from the data. The wide range of inferred values, particularly for the mass ratio and the effective spin `chi_eff`, means that drawing firm conclusions about the source's formation history (e.g., isolated binary evolution vs. dynamical capture in a dense cluster) is not possible without addressing these waveform systematics. The analysis demonstrates that the choice of waveform model is not merely a technical detail but a dominant factor in the scientific interpretation of such events.