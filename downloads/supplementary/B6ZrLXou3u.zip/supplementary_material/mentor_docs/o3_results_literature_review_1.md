<response>
State of the art (2024–2025) at a glance
Research on detecting LLM jailbreaks has broadened well beyond “is the output toxic?” classifiers. Current methods fall into five primary families: (A) white-box, internals-based monitors (gradients, losses, activations); (B) decoding-time safety signals and certified/aggregated inference; (C) black-box behavioral-consistency detectors built from input/output perturbations; (D) multi-model or agentic defenders that use a separate “guard” model; and (E) multimodal-specific detectors for LVLMs. Below I summarize each category, highlight representative techniques, and note key limitations and open directions. This taxonomy should make it straightforward to situate a new behavioral consistency metric alongside prior black-box methods.

A. White-box, internals-based jailbreak detectors
A1. Gradient- and loss-landscape-based detection
- GradSafe: detect jailbreak prompts by comparing gradients on safety-critical parameters; harmful prompts paired with compliant responses share characteristic gradient signatures, enabling thresholding without finetuning the target model (Xie et al., 2024). ([arxiv.org](https://arxiv.org/abs/2402.13494?utm_source=openai))
- Gradient Cuff: define a refusal loss and use its value and (estimated) gradient norm as two-stage indicators; higher gradient norms and specific smoothness properties flag adversarial queries (Hu et al., 2024). ([arxiv.org](https://arxiv.org/abs/2403.00867?utm_source=openai))
- GradCoo: extend gradient-based detectors via gradient co-occurrence (unsigned similarity) to reduce directional bias and improve recall on ToxicChat/XSTest (Yang et al., 2025). ([arxiv.org](https://arxiv.org/abs/2502.12411?utm_source=openai))

Why it matters: these approaches leverage the model’s own optimization geometry to differentiate benign vs. adversarial inputs and can work tuning-free or with few-shot references. Threats: zeroth-order estimators can be query-expensive; adaptive attackers may optimize to evade the specific gradient statistic being monitored. ([arxiv.org](https://arxiv.org/abs/2403.00867?utm_source=openai))

A2. Hidden-state and representation probes
- HiddenDetect (ACL 2025): measure distinct internal activation patterns in LVLMs for unsafe vs. benign prompts and detect/mitigate jailbreaks in a tuning-free manner (Jiang et al., 2025). ([aclanthology.org](https://aclanthology.org/2025.acl-long.724/?utm_source=openai), [arxiv.org](https://arxiv.org/abs/2502.14744?utm_source=openai))
- Hidden State Filtering (HSF): plug-in “hidden state filter” that classifies pre-inference hidden states to preemptively block adversarial prompts, exploiting clustering structure of safe/harmful/jailbreak states (Qian et al., 2024). ([arxiv.org](https://arxiv.org/abs/2409.03788?utm_source=openai))
- Concept-activation and linear directions: refusal behavior can be largely captured by a single linear subspace; projection/steering along this direction modulates refusal (Arditi et al., NeurIPS 2024). Defenses can probe this subspace to detect suppression typical of jailbreaks (but see limitations below) (Arditi et al., 2024). ([arxiv.org](https://arxiv.org/abs/2406.11717?utm_source=openai), [proceedings.neurips.cc](https://proceedings.neurips.cc/paper_files/paper/2024/hash/f545448535dfde4f9786555403ab7c49-Abstract-Conference.html?utm_source=openai))
- JBShield (2025): extract “toxic” and “jailbreak” concepts as subspaces; a prompt that co-activates both indicates a jailbreak attempt; mitigation steers activations to strengthen toxic-concept detection and weaken jailbreak-concept influence (Zhang et al., 2025). ([arxiv.org](https://arxiv.org/abs/2502.07557?utm_source=openai))
- SAE-based steering/monitoring: sparse autoencoders identify refusal-mediating features that can be monitored or steered at inference time (O’Brien et al., 2024). ([arxiv.org](https://arxiv.org/abs/2411.11296?utm_source=openai))

Known limitation: “obfuscated activations.” Recent work shows latent-space monitors (linear probes, SAEs, latent OOD) can be deliberately fooled while preserving harmful behavior—highlighting the need for ensembles and adversarially trained monitors (Bailey et al., 2024). ([arxiv.org](https://arxiv.org/abs/2412.09565?utm_source=openai))

A3. Early-layer/early-exit signals
- EEG-Defender: exploit that early transformer-layer representations of jailbreak prompts resemble malicious prompts; early-exit generation terminates on detection, reducing ASR with minimal utility loss (Zhao et al., 2024). ([arxiv.org](https://arxiv.org/abs/2408.11308?utm_source=openai))

B. Decoding-time safety signals and certified/aggregated inference
B1. Safety-aware token gating
- SafeDecoding (ACL 2024): combine next-token distributions of base and safety-expert models; emphasize safety tokens (e.g., disclaimers/refusals) to suppress harmful continuations (Xu et al., 2024). ([aclanthology.org](https://aclanthology.org/2024.acl-long.303/?utm_source=openai))
- Alignment-Enhanced Decoding (EMNLP 2024): adaptively refine logits using a Competitive Index and self-evaluation feedback to maintain helpfulness while avoiding policy violations (EMNLP 2024). ([aclanthology.org](https://aclanthology.org/2024.emnlp-main.164/?utm_source=openai))

B2. Randomized/semantic smoothing and certified detectors
- SemanticSmooth (2024): apply semantic-preserving transformations (synonyms, tense changes, translation, summarization), then aggregate outputs; robustness emerges from agreement across semantically equivalent variants (Ji et al., 2024). ([arxiv.org](https://arxiv.org/abs/2402.16192?utm_source=openai))
- Erase-and-Check with certificates (Kumar et al., 2023): systematically delete tokens and reclassify to obtain certified guarantees up to a perturbation size; strong as an input-side detector for suffix/insertion/infusion attacks (Kumar et al., 2023). ([arxiv.org](https://arxiv.org/abs/2309.02705?utm_source=openai))

B3. Self-evaluation with rewind
- RAIN (ICLR 2024): at inference time, the model self-evaluates partial generations and can rewind to safer continuations; useful as a dynamic detector/mitigator of unsafe trajectories (Li et al., 2024). ([arxiv.org](https://arxiv.org/abs/2309.07124?utm_source=openai))

C. Black-box behavioral-consistency detectors (input/output perturbation)
C1. Backtranslation reveal-and-refuse
- Backtranslation defense: infer a prompt from the model’s initial response (reverse mapping) to surface the “true intent,” then re-run and refuse if unsafe; shows strong gains where direct classifiers fail (Wang et al., 2024). ([arxiv.org](https://arxiv.org/abs/2402.16459?utm_source=openai))

C2. Repetition-based trap (autoregressive consistency)
- PARDEN (ICML 2024): ask the model to repeat its own output; benign content repeats consistently, while adversarial generations often fail to repeat safely; this reduces FPR at high TPRs compared to baselines (Zhang et al., 2024). ([proceedings.mlr.press](https://proceedings.mlr.press/v235/zhang24ca.html?utm_source=openai), [blog.foersterlab.com](https://blog.foersterlab.com/parden/?utm_source=openai))

C3. Mutation/paraphrase/deletion ensembles
- Families of perturbation-based detectors—including paraphrasing, random deletion (“erase-and-check”), and retokenization—use robustness to small edits as a black-box signal of safety; perplexity-only filters are weak alone but are useful in ensembles (Kumar et al., 2023; Alon & Kamfonas, 2023). ([arxiv.org](https://arxiv.org/abs/2309.02705?utm_source=openai))

Where a new behavioral consistency metric fits: Your metric would naturally belong here (C), alongside backtranslation and PARDEN. If it scores the stability of refusals/helpful-but-safe responses under semantically preserving perturbations (paraphrase, format changes, translation, role or style shifts), you can position it as a generalized consistency detector that subsumes specific tactics like repetition/backtranslation while avoiding their corner cases (see “Positioning and evaluation,” below).

D. Multi-model and agentic defenders (external “guard” models)
- SelfDefend (2024): a “shadow” LLM runs in detection state alongside the target model; distilled lighter guards can reduce cost and retain robustness across attacks (Wang et al., 2024). ([arxiv.org](https://arxiv.org/abs/2406.05498?utm_source=openai))
- AutoDefense (2024): multi-agent pipeline in which specialized guard agents collaborate to filter harmful responses across different attack styles (Zeng et al., 2024). ([arxiv.org](https://arxiv.org/abs/2403.04783?utm_source=openai))
- Constitutional Classifiers (Anthropic, 2025): an input/output classifier stack trained on constitutional principles; reported large reductions in jailbreak success at moderate compute overhead, with small overrefusal increases in production (Anthropic, 2025). ([anthropic.com](https://www.anthropic.com/research/constitutional-classifiers?utm_source=openai))
- Robust safety classifiers: adversarially trained prompt-injection/safety detectors (e.g., Adversarial Prompt Shield) to harden detectors themselves (Kim et al., 2024). ([aclanthology.org](https://aclanthology.org/2024.woah-1.12/?utm_source=openai))

E. Multimodal jailbreak detection (LVLMs)
- HiddenDetect (ACL 2025): monitor cross-modal hidden states to detect unsafe prompts/images without fine-tuning (Jiang et al., 2025). ([aclanthology.org](https://aclanthology.org/2025.acl-long.724/?utm_source=openai))
- AdaShield (ECCV 2024): “adaptive shield prompting” to defend structure-based attacks where images contain embedded harmful text; can operate in black-box settings (Wang et al., 2024). ([dl.acm.org](https://dl.acm.org/doi/10.1007/978-3-031-72661-3_5?utm_source=openai), [arxiv.org](https://arxiv.org/abs/2403.09513?utm_source=openai))

Cross-cutting notes on benchmarks and attacks
- Many detectors report on AdvBench, ToxicChat, XSTest, HarmBench, and curated attack suites (GCG, AutoDAN, PAIR/TAP, Base64/cipher, multilingual/indirect injections); results are sensitive to which attacks/targets are used. For example, GradSafe used ToxicChat/XSTest; Gradient Cuff evaluated across six attack types; more recent works target LVLMs specifically. ([arxiv.org](https://arxiv.org/abs/2402.13494?utm_source=openai))

Limitations and active debates
- Latent monitor brittleness: activation/probe/SAE monitors can be bypassed via “obfuscated activations,” suggesting latent detectors should be adversarially trained, diversified across layers/tokens, and combined with behavioral checks (Bailey et al., 2024). ([arxiv.org](https://arxiv.org/abs/2412.09565?utm_source=openai))
- Query/computation budget: gradient/loss-landscape methods often require multiple forward passes or zeroth-order gradient estimation; practical systems combine cheap prefilters with heavier checks only on suspicious cases (Hu et al., 2024; Xu et al., 2024). ([arxiv.org](https://arxiv.org/abs/2403.00867?utm_source=openai), [aclanthology.org](https://aclanthology.org/2024.acl-long.303/?utm_source=openai))
- Overrefusal vs. coverage: strong guards (e.g., constitutional classifiers) reduce universal jailbreaks but risk usability/latency costs; newer variants report minimal refusal increases but still recommend layered defenses (Anthropic, 2025). ([anthropic.com](https://www.anthropic.com/research/constitutional-classifiers?utm_source=openai))
- Multimodal/new vectors: LVLM-specific attacks (e.g., adversarial images or instruction-in-image) demand cross-modal activation monitoring; detectors trained only on text may not transfer (Rando et al., 2024; AdaShield, 2024; HiddenDetect, 2025). ([arxiv.org](https://arxiv.org/abs/2410.03489?utm_source=openai), [dl.acm.org](https://dl.acm.org/doi/10.1007/978-3-031-72661-3_5?utm_source=openai), [aclanthology.org](https://aclanthology.org/2025.acl-long.724/?utm_source=openai))

Positioning a new behavioral consistency metric
- Placement in taxonomy: Category C (black-box behavioral-consistency detectors).
- Design recommendations:
  - Transformation family: include paraphrases, format obfuscations (lists/code blocks/roleplay), language switches (en↔hi/ta), encoding/decoding steps (simple cipher/base64), and response-style prompts (justifications vs. terse) to stress-test consistency of safe behavior. This spans the known evasion space without requiring internals. Compare to backtranslation (Wang et al., 2024) and repetition (Zhang et al., 2024). ([arxiv.org](https://arxiv.org/abs/2402.16459?utm_source=openai), [proceedings.mlr.press](https://proceedings.mlr.press/v235/zhang24ca.html?utm_source=openai))
  - Scoring: define an agreement function over refusal and harmlessness judgments across transformations; optionally weight by lexical/semantic distance to avoid gaming via trivial near-duplicates (cf. SemanticSmooth aggregation ideas). ([arxiv.org](https://arxiv.org/abs/2402.16192?utm_source=openai))
  - Decision policy: use the metric as a triage signal—if low consistency, escalate to heavier checks (activation probes, SafeDecoding) or a guard model (SelfDefend/constitutional classifier). ([aclanthology.org](https://aclanthology.org/2024.acl-long.303/?utm_source=openai), [arxiv.org](https://arxiv.org/abs/2406.05498?utm_source=openai), [anthropic.com](https://www.anthropic.com/research/constitutional-classifiers?utm_source=openai))
  - Adversarial evaluation: include adaptive attackers that optimize to maximize your consistency score while eliciting unsafe outputs (e.g., PAIR/TAP variants, cipher/encoding, multilingual). Report robustness gaps relative to PARDEN/backtranslation and internals-based baselines (GradSafe/Gradient Cuff). ([arxiv.org](https://arxiv.org/abs/2403.00867?utm_source=openai))
- Why it adds value: Unlike single-perturbation detectors, a calibrated consistency metric can unify multiple black-box tests into a single risk score that tracks “safety invariance” across plausible rephrasings and encodings, complementing latent monitors that may be obfuscated (Bailey et al., 2024). ([arxiv.org](https://arxiv.org/abs/2412.09565?utm_source=openai))

Future directions
- Hybrid white-box + black-box stacks: combine latent monitors (multi-layer, multi-token, adversarially trained) with behavioral-consistency scores and decoding-time gating for defense-in-depth. ([arxiv.org](https://arxiv.org/abs/2412.09565?utm_source=openai), [aclanthology.org](https://aclanthology.org/2024.acl-long.303/?utm_source=openai))
- Certified behavioral detectors: extend semantic/erase-and-check style certificates to richer perturbation families (format switching, multilingual) and to session-level multi-turn consistency. ([arxiv.org](https://arxiv.org/abs/2309.02705?utm_source=openai))
- LVLM-generalized detectors: use cross-modal concept activation vectors or autoencoder-based anomaly detection trained on safe distributions only, to handle unknown attacks (Jiang et al., 2025). ([aclanthology.org](https://aclanthology.org/2025.acl-long.724/?utm_source=openai))

References:
Arditi, A., Obeso, O., Syed, A., Paleka, D., Panickssery, N., Gurnee, W., & Nanda, N. (2024). Refusal in Language Models Is Mediated by a Single Direction. NeurIPS. ([proceedings.neurips.cc](https://proceedings.neurips.cc/paper_files/paper/2024/hash/f545448535dfde4f9786555403ab7c49-Abstract-Conference.html?utm_source=openai))
Bailey, L., Serrano, A., Sheshadri, A., Seleznyov, M., Taylor, J., Jenner, E., Hilton, J., Guestrin, C., & Emmons, S. (2024). Obfuscated Activations Bypass LLM Latent-Space Defenses. arXiv. ([arxiv.org](https://arxiv.org/abs/2412.09565?utm_source=openai))
Hu, X., Chen, P.-Y., & Ho, T.-Y. (2024). Gradient Cuff: Detecting Jailbreak Attacks on Large Language Models by Exploring Refusal Loss Landscapes. arXiv. ([arxiv.org](https://arxiv.org/abs/2403.00867?utm_source=openai))
Jiang, Y., Gao, X., Peng, T., Tan, Y., Zhu, X., Zheng, B., & Yue, X. (2025). HiddenDetect: Detecting Jailbreak Attacks against Multimodal LLMs via Monitoring Hidden States. ACL. ([aclanthology.org](https://aclanthology.org/2025.acl-long.724/?utm_source=openai))
Ji, J., Hou, B., Robey, A., Pappas, G. J., Hassani, H., Zhang, Y., & Wong, E. (2024). Defending Large Language Models against Jailbreak Attacks via Semantic Smoothing. arXiv. ([arxiv.org](https://arxiv.org/abs/2402.16192?utm_source=openai))
Kim, J., Derakhshan, A., & Harris, I. (2024). Robust Safety Classifier Against Jailbreaking Attacks: Adversarial Prompt Shield. WOAH 2024. ([aclanthology.org](https://aclanthology.org/2024.woah-1.12/?utm_source=openai))
Kumar, A., Agarwal, C., Srinivas, S., Li, A. J., Feizi, S., & Lakkaraju, H. (2023). Certifying LLM Safety against Adversarial Prompting. arXiv. ([arxiv.org](https://arxiv.org/abs/2309.02705?utm_source=openai))
Li, Y., Wei, F., Zhao, J., Zhang, C., & Zhang, H. (2024). RAIN: Your Language Models Can Align Themselves without Finetuning. ICLR. ([arxiv.org](https://arxiv.org/abs/2309.07124?utm_source=openai))
O’Brien, K., Majercak, D., Fernandes, X., Edgar, R., Chen, J., Nori, H., Carignan, D., Horvitz, E., & Poursabzi-Sangdeh, F. (2024). Steering Language Model Refusal with Sparse Autoencoders. arXiv. ([arxiv.org](https://arxiv.org/abs/2411.11296?utm_source=openai))
Qian, C., Zhang, H., Sha, L., & Zheng, Z. (2024). HSF: Defending against Jailbreak Attacks with Hidden State Filtering. arXiv. ([arxiv.org](https://arxiv.org/abs/2409.03788?utm_source=openai))
Wang, X., Wu, D., Ji, Z., Li, Z., Ma, P., Wang, S., Liu, Y., Liu, N., & Rahmel, J. (2024). SelfDefend: LLMs Can Defend Themselves against Jailbreaking in a Practical Manner. arXiv. ([arxiv.org](https://arxiv.org/abs/2406.05498?utm_source=openai))
Wang, Y., Shi, Z., Bai, A., & Hsieh, C.-J. (2024). Defending LLMs against Jailbreaking Attacks via Backtranslation. arXiv. ([arxiv.org](https://arxiv.org/abs/2402.16459?utm_source=openai))
Xu, Z., Jiang, F., Niu, L., Jia, J., Lin, B. Y., & Poovendran, R. (2024). SafeDecoding: Defending against Jailbreak Attacks via Safety-Aware Decoding. ACL. ([aclanthology.org](https://aclanthology.org/2024.acl-long.303/?utm_source=openai))
Xie, Y., Fang, M., Pi, R., & Gong, N. (2024). GradSafe: Detecting Jailbreak Prompts for LLMs via Safety-Critical Gradient Analysis. arXiv/ACL. ([arxiv.org](https://arxiv.org/abs/2402.13494?utm_source=openai))
Yang, J., Yan, B., Li, R., Zhou, Z., Chen, X., Feng, Z., & Peng, W. (2025). Gradient Co-occurrence Analysis for Detecting Unsafe Prompts in LLMs. arXiv. ([arxiv.org](https://arxiv.org/abs/2502.12411?utm_source=openai))
Zeng, Y., Wu, Y., Zhang, X., Wang, H., & Wu, Q. (2024). AutoDefense: Multi-Agent LLM Defense against Jailbreak Attacks. arXiv. ([arxiv.org](https://arxiv.org/abs/2403.04783?utm_source=openai))
Zhang, Z., Zhang, Q., & Foerster, J. N. (2024). PARDEN, Can You Repeat That? Defending against Jailbreaks via Repetition. ICML. ([proceedings.mlr.press](https://proceedings.mlr.press/v235/zhang24ca.html?utm_source=openai))
Zhang, S., Zhai, Y., Guo, K., Hu, H., Guo, S., Fang, Z., Zhao, L., Shen, C., Wang, C., & Wang, Q. (2025). JBShield: Defending LLMs from Jailbreaks through Activated Concept Analysis and Manipulation. arXiv. ([arxiv.org](https://arxiv.org/abs/2502.07557?utm_source=openai))
Wang, Y., Liu, X., Li, Y., Chen, M., & Xiao, C. (2024). AdaShield: Safeguarding Multimodal LLMs from Structure-based Attack via Adaptive Shield Prompting. ECCV. ([dl.acm.org](https://dl.acm.org/doi/10.1007/978-3-031-72661-3_5?utm_source=openai))
Anthropic Safeguards Research Team. (2025). Constitutional Classifiers: Defending against Universal Jailbreaks. Research blog/paper. ([anthropic.com](https://www.anthropic.com/research/constitutional-classifiers?utm_source=openai))
Zhao, C., Dou, Z., & Huang, K. (2024). EEG-Defender: Early Exit Generation to Defend Jailbreaks. arXiv. ([arxiv.org](https://arxiv.org/abs/2408.11308?utm_source=openai))

</response>