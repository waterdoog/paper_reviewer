# Network-Constrained Truth Recovery

A simulation system for studying how distributed agents can recover hidden truth through network-constrained communication.

## 📁 Project Files

### **Core Simulation Files**
- **`orchestrator.py`** - Original simulation with LLM integration (has contradiction flaw)
- **`orchestrator_contradiction_fixed.py`** - FIXED version with proper contradiction resolution
- **`orchestrator_detailed_log.py`** - Enhanced version with detailed logging
- **`03_sim_baseline.py`** - Minimal baseline simulation implementation

### **Configuration & Analysis**
- **`config.py`** - Centralized parameter configuration system
- **`analyze_log.py`** - Tool for analyzing simulation results

### **Data Files**
- **`ca-GrQc.txt`** - Original SNAP collaboration network dataset
- **`grqc_undirected.edgelist`** - Processed undirected graph (4,158 nodes, 13,422 edges)
- **`run_log.csv`** - Experiment results log

### **Utilities**
- **`01_load_grqc.py`** - Graph loading utilities
- **`02_degree_stats.py`** - Network statistics analysis
- **`openrouter_test.py`** - API testing for LLM integration
- **`requirements.txt`** - Python dependencies

## 🚀 Quick Start

### **Run the Fixed Simulation**
```bash
python orchestrator_contradiction_fixed.py --seed 42 --max_rounds 50
```

### **Run with Detailed Logging**
```bash
python orchestrator_detailed_log.py --seed 42 --max_rounds 10
```

### **Analyze Results**
```bash
python analyze_log.py
```

## 🔧 Key Features

### **Fixed Contradiction Resolution**
- **Problem:** Original system allowed contradictory beliefs
- **Solution:** Majority vote resolution for fact vs. negation conflicts
- **Impact:** Logically consistent agent knowledge bases

### **Network-Constrained Communication**
- Agents share facts only along network edges
- Real collaboration network (ca-GrQc) with 4,158 researchers
- Configurable sharing budget (facts per neighbor per round)

### **LLM-Powered Fact Generation**
- Uses Llama-3 via OpenRouter for realistic fact generation
- Closed universe: 20 fact pairs (fact + negation)
- Hidden truth set: Exactly one from each pair

## 📊 Current Results

- **Best Performance:** 18/20 correct facts (90% accuracy)
- **Convergence Rate:** 0% (no full recovery achieved)
- **Key Finding:** Contradiction resolution is critical for accurate metrics

## 🎯 Next Steps

1. **Parameter Optimization** - Test different noise regimes and network topologies
2. **Advanced Scoring** - Implement Bayesian and centrality-weighted methods
3. **Convergence Analysis** - Study why full recovery is difficult
4. **Network Effects** - Analyze how topology affects information spread

## ⚠️ Important Notes

- **Use `orchestrator_contradiction_fixed.py`** for accurate results
- **Original `orchestrator.py`** has the contradiction flaw
- **Detailed logging** generates large files (10MB+)
- **LLM calls** require valid OpenRouter API key
