# Uncertainty-Aware Role-Switching Debate: Improving Truthfulness in Large Language Models

This repository is the official implementation of the Uncertainty-Aware Role-Switching Debate protocol.

Run the protocol with:

```bash
python debate.py 

```

We are using the Vertex AI API to query the Gemini model. Please change line 11 to use your open Google Cloud project.

Our results can be found in openbook_debate_transcript.json




