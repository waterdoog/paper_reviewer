"""
Core model classes for the models package.
""" 