"""
Report Section Generators
"""

from .base import SectionGenerator

__all__ = ["SectionGenerator"]