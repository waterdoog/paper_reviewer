"""Service layer for literature query system"""

from .literature_service import LiteratureService

__all__ = [
    "LiteratureService"
]