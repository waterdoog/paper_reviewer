"""
Bidirectional Cognitive Adaptation (BiCA) Framework
"""

__version__ = "0.1.0"
__author__ = "BiCA Team"
