# Code: Information-Efficient Transformers via Adaptive Token Pruning

## 1) Synthetic (NumPy-only, deterministic)
```bash
python -m code.experiment_runner --out results/$(date +%Y%m%d_%H%M%S) --seed 2025
